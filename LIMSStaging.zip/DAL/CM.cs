﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Data;

namespace LIMS.DAL
{

    public class CM
    {
        SqlConnection _sCon = new SqlConnection(ConfigurationManager.ConnectionStrings["CM"].ConnectionString);

        string sQuery = "";
        DataTable dt = new DataTable();

        string _customerType;
        bool _status;
        string _title;
        string _firstName;
        string _middleName;
        string _lastName;
        string _EmployeeName;
        string _EmployeeID;
        int _empID;
        int _roleID;
        int _customerMasterId;
        string _groupName;
        string _subGroup;
        string _companyName;
        string _tradingName;
        string _location;
        string _locationName;
        string _addressLine1;
        string _addressLine2;
        string _addressLine3;
        string _country;
        string _state;
        string _district;
        string _taluka;
        string _city;
        string _suburb;
        string _pincode;
        string _locationAddressType;
        int _customerId;
        int _companyId;
        int _groupId;
        string _inquiry;
        DateTime _created;
        string _inquiryStatus;
        int _personId;
        int _inquiryStatusId;
        DateTime _dateOfRequest;
        int _inquiryId;
        string _customerName;
        string _phone;
        string _mobile;
        string _fax;
        string _email;
        string _designation;
        int _designationID;
        string _department;
        int _departmentID;
        string _shippingAgency;
        string _airwayBillNo;
        int _sampleId;
        string _sampleIDSeries;
        int _CRFSampleId;
        int _CRFID;
        string _sampleName;
        string _batchNo;
        string _testMethod;
        string _testParameter;
        string _specification;
        string _unit;
        string _sizeOfSample;
        string _remarks;
        int _customerRequestId;
        int _requestTypeId;
        string _customerSignature;
        string _description;
        string _expectedValue;
        string _dimensions;
        string _description2;
        string _description3;
        int _CustomerUID;
        string _employeID;
        string _employeeDepartment;
        int _employeeDepartmentID;
        string _productCategory;
        int _subgroupid;
        DateTime _receivedDate;
        DateTime _destroyDate;
        string _sampleChecklistId;
        bool _sampleChecklistStatus;
        string _sampleChecklistName;
        string _sampleHistory;
        int _sampleStatusID;
        string _message;
        string _testResult;
        string _username;
        string _password;
        string _reportNo;
        string _ulrNo;
        DateTime _issueDate;
        string _standardWVTR;
        string _standardOTR;
        string _methodWVTR;
        string _methodOTR;
        string _roomTempWVTR;
        string _roomTempOTR;
        string _testTempWVTR;
        string _testTempOTR;
        string _testRHWVTR;
        string _testRHOTR;
        string _carrierRHWVTR;
        string _carrierRHOTR;
        string _conditioningWVTR;
        string _conditioningOTR;
        string _testAreaWVTR;
        string _testAreaOTR;
        string _testGasSideWVTR;
        string _testGasSideOTR;
        string _o2WVTR;
        string _o2OTR;
        string _testOperatorWVTR;
        string _testOperatorOTR;
        string _labSampleId;
        string _sampling;
        string _samplingCondition;
        string _modelPTI;
        DateTime _calDueDatePTI;
        string _modelWVTR;
        string _srNoWVTR;
        string _calCerficateNoWVTR;
        DateTime _calCertificateDateWVTR;
        DateTime _calDueDateWVTR;
        string _calByWVTR;
        string _calAtWVTR;
        string _modelOTR;
        string _srNoOTR;
        string _calCerficateNoOTR;
        DateTime _calCertificateDateOTR;
        DateTime _calDueDateOTR;
        string _calByOTR;
        string _calAtOTR;
        string _sampleDescription;
        DateTime _testDateWVTR;
        string _testNoWVTR;
        string _gDayWVTR;
        DateTime _testDateOTR;
        string _testNoOTR;
        string _gDayOTR;
        DateTime _analysisStartingDate;
        DateTime _analysisCompletionDate;
        string _nameOfProduct;
        string _typeOfSample;
        string _InstrumentDetails;
        string _referenceMaterialDetails;
        string _dateOfMfg;
        string _dateOfExp;
        string _sampleQuality;
        string _testRequired;
        string _sampleCondition;
        string _samplingMethod;
        string _feedbackName;
        string _feedbackValue;
        string _customerRemark;
        DateTime _feedbackDate;
        int _feedbackWeightage;
        int _userStatus;
        string _ScriptSample;
        string _testsRequested;
        string _sampleConditionRemarks;
        string _SampleCheckListValue;
        int _SampleVerifiedBy;
        string _Temp;
        string _RH;
        string _WVTRResult;
        string _OTRResult;
        string _WVTRTestDate;
        string _OTRTestDate;
        string _WVTRTestNo;
        string _OTRTestNo;
        int _sampleCategoryID;
        int _CustomerCRFSampleID;
        int _CloneCRFSampleID;
        int _CRFStatusID;
        string _SampleType;

        public string customerType
        {
            get { return _customerType; }
            set { _customerType = value; }
        }
        public bool status
        {
            get { return _status; }
            set { _status = value; }
        }
        public int userStatus
        {
            get { return _userStatus; }
            set { _userStatus = value; }
        }
        public string title
        {
            get { return _title; }
            set { _title = value; }
        }
        public string firstName
        {
            get { return _firstName; }
            set { _firstName = value; }
        }
        public string middleName
        {
            get { return _middleName; }
            set { _middleName = value; }
        }
        public string lastName
        {
            get { return _lastName; }
            set { _lastName = value; }
        }
        public string EmployeeName
        {
            get { return _EmployeeName; }
            set { _EmployeeName = value; }
        }
        public string EmployeeID
        {
            get { return _EmployeeID; }
            set { _EmployeeID = value; }
        }
        public int CustomerMasterId
        {
            get { return _customerMasterId; }
            set { _customerMasterId = value; }
        }
        public string GroupName
        {
            get { return _groupName; }
            set { _groupName = value; }
        }
        public string subGroup { get { return _subGroup; } set { _subGroup = value; } }

        public string CompanyName
        {
            get { return _companyName; }
            set { _companyName = value; }
        }
        public string TradingName
        {
            get { return _tradingName; }
            set { _tradingName = value; }
        }
        public string location
        {
            get { return _location; }
            set { _location = value; }
        }
        public string locationName
        {
            get { return _locationName; }
            set { _locationName = value; }
        }
        public string addressLine1
        {
            get { return _addressLine1; }
            set { _addressLine1 = value; }
        }
        public string addressLine2
        {
            get { return _addressLine2; }
            set { _addressLine2 = value; }
        }
        public string addressLine3
        {
            get { return _addressLine3; }
            set { _addressLine3 = value; }
        }
        public string country
        {
            get { return _country; }
            set { _country = value; }
        }
        public string state
        {
            get { return _state; }
            set { _state = value; }
        }
        public string district
        {
            get { return _district; }
            set { _district = value; }
        }
        public string taluka
        {
            get { return _taluka; }
            set { _taluka = value; }
        }
        public string city
        {
            get { return _city; }
            set { _city = value; }
        }
        public string suburb
        {
            get { return _suburb; }
            set { _suburb = value; }
        }
        public string pincode
        {
            get { return _pincode; }
            set { _pincode = value; }
        }
        public string locationAddressType
        {
            get { return _locationAddressType; }
            set { _locationAddressType = value; }
        }
        public int customerId
        {
            get { return _customerId; }
            set { _customerId = value; }
        }
        public int companyId
        {
            get { return _companyId; }
            set { _companyId = value; }
        }
        public int groupId
        {
            get { return _groupId; }
            set { _groupId = value; }
        }
        public string inquiry
        {
            get { return _inquiry; }
            set { _inquiry = value; }
        }
        public DateTime created
        {
            get { return _created; }
            set { _created = value; }
        }
        public string inquiryStatus
        {
            get { return _inquiryStatus; }
            set { _inquiryStatus = value; }
        }
        public int personId
        {
            get { return _personId; }
            set { _personId = value; }
        }
        public int inquiryStatusId
        {
            get { return _inquiryStatusId; }
            set { _inquiryStatusId = value; }
        }
        public DateTime dateOfRequest
        {
            get { return _dateOfRequest; }
            set { _dateOfRequest = value; }
        }
        public int inquiryId
        {
            get { return _inquiryId; }
            set { _inquiryId = value; }
        }
        public string customerName
        {
            get { return _customerName; }
            set { _customerName = value; }
        }
        public string phone
        {
            get { return _phone; }
            set { _phone = value; }
        }
        public string mobile
        {
            get { return _mobile; }
            set { _mobile = value; }
        }
        public string fax
        {
            get { return _fax; }
            set { _fax = value; }
        }
        public string email
        {
            get { return _email; }
            set { _email = value; }
        }
        public string designation
        {
            get { return _designation; }
            set { _designation = value; }
        }
        public int designationID
        {
            get { return _designationID; }
            set { _designationID = value; }
        }
        public int departmentID { get { return _departmentID; } set { _departmentID = value; } }

        public string department
        {
            get { return _department; }
            set { _department = value; }
        }
        public string shippingAgency
        {
            get { return _shippingAgency; }
            set { _shippingAgency = value; }
        }
        public string airwayBillNo
        {
            get { return _airwayBillNo; }
            set { _airwayBillNo = value; }
        }
        public string sampleName
        {
            get { return _sampleName; }
            set { _sampleName = value; }
        }
        public string batchNo
        {
            get { return _batchNo; }
            set { _batchNo = value; }
        }
        public string testMethod
        {
            get { return _testMethod; }
            set { _testMethod = value; }
        }
        public string testParameter
        {
            get { return _testParameter; }
            set { _testParameter = value; }
        }
        public string specification
        {
            get { return _specification; }
            set { _specification = value; }
        }
        public string unit
        {
            get { return _unit; }
            set { _unit = value; }
        }
        public string sizeOfSample
        {
            get { return _sizeOfSample; }
            set { _sizeOfSample = value; }
        }
        public string remarks
        {
            get { return _remarks; }
            set { _remarks = value; }
        }
        public int customerRequestId
        {
            get { return _customerRequestId; }
            set { _customerRequestId = value; }
        }
        public int requestTypeId
        {
            get { return _requestTypeId; }
            set { _requestTypeId = value; }
        }
        public string customerSignature
        {
            get { return _customerSignature; }
            set { _customerSignature = value; }
        }
        public string description
        {
            get { return _description; }
            set { _description = value; }
        }
        public string expectedValue
        {
            get { return _expectedValue; }
            set { _expectedValue = value; }
        }
        public string dimensions
        {
            get { return _dimensions; }
            set { _dimensions = value; }
        }
        public string description2
        {
            get { return _description2; }
            set { _description2 = value; }
        }
        public string description3
        {
            get { return _description3; }
            set { _description3 = value; }
        }
        public int sampleId
        {
            get { return _sampleId; }
            set { _sampleId = value; }
        }
        public string sampleIDSeries
        {
            get { return _sampleIDSeries; }
            set { _sampleIDSeries = value; }
        }
        public int CRFSampleId
        {
            get { return _CRFSampleId; }
            set { _CRFSampleId = value; }
        }
        public int CustomerUID
        {
            get { return _CustomerUID; }
            set { _CustomerUID = value; }
        }
        public string employeID
        {
            get { return _employeID; }
            set { _employeID = value; }
        }
        public int empID
        {
            get { return _empID; }
            set { _empID = value; }
        }
        public int roleID
        {
            get { return _roleID; }
            set { _roleID = value; }
        }
        public int employeeDepartmentID
        {
            get { return _employeeDepartmentID; }
            set { _employeeDepartmentID = value; }
        }
        public string employeeDepartment
        {
            get { return _employeeDepartment; }
            set { _employeeDepartment = value; }
        }
        public int subgroupid
        {
            get { return _subgroupid; }
            set { _subgroupid = value; }
        }
        public string productCategory
        {
            get { return _productCategory; }
            set { _productCategory = value; }
        }
        public DateTime receivedDate
        {
            get { return _receivedDate; }
            set { _receivedDate = value; }
        }
        public DateTime destroyDate
        {
            get { return _destroyDate; }
            set { _destroyDate = value; }
        }
        public string sampleChecklistId
        {
            get { return _sampleChecklistId; }
            set { _sampleChecklistId = value; }
        }
        public bool sampleChecklistStatus
        {
            get { return _sampleChecklistStatus; }
            set { _sampleChecklistStatus = value; }
        }
        public string sampleChecklistName
        {
            get { return _sampleChecklistName; }
            set { _sampleChecklistName = value; }
        }
        public string sampleHistory
        {
            get { return _sampleHistory; }
            set { _sampleHistory = value; }
        }
        public int sampleStatusID
        {
            get { return _sampleStatusID; }
            set { _sampleStatusID = value; }
        }
        public string message
        {
            get { return _message; }
            set { _message = value; }
        }
        public string testResult
        {
            get { return _testResult; }
            set { _testResult = value; }
        }
        public string username
        {
            get { return _username; }
            set { _username = value; }
        }
        public string password
        {
            get { return _password; }
            set { _password = value; }
        }
        public string reportNo
        {
            get { return _reportNo; }
            set { _reportNo = value; }
        }
        public string ulrNo
        {
            get { return _ulrNo; }
            set { _ulrNo = value; }
        }
        public DateTime issueDate
        {
            get { return _issueDate; }
            set { _issueDate = value; }
        }
        public string standardWVTR
        {
            get { return _standardWVTR; }
            set { _standardWVTR = value; }
        }
        public string standardOTR
        {
            get { return _standardOTR; }
            set { _standardOTR = value; }
        }
        public string methodWVTR
        {
            get { return _methodWVTR; }
            set { _methodWVTR = value; }
        }
        public string methodOTR
        {
            get { return _methodOTR; }
            set { _methodOTR = value; }
        }
        public string roomTempWVTR
        {
            get { return _roomTempWVTR; }
            set { _roomTempWVTR = value; }
        }
        public string roomTempOTR
        {
            get { return _roomTempOTR; }
            set { _roomTempOTR = value; }
        }
        public string testTempWVTR
        {
            get { return _testTempWVTR; }
            set { _testTempWVTR = value; }
        }
        public string testTempOTR
        {
            get { return _testTempOTR; }
            set { _testTempOTR = value; }
        }
        public string testRHWVTR
        {
            get { return _testRHWVTR; }
            set { _testRHWVTR = value; }
        }
        public string testRHOTR
        {
            get { return _testRHOTR; }
            set { _testRHOTR = value; }
        }
        public string carrierRHWVTR
        {
            get { return _carrierRHWVTR; }
            set { _carrierRHWVTR = value; }
        }
        public string carrierRHOTR
        {
            get { return _carrierRHOTR; }
            set { _carrierRHOTR = value; }
        }
        public string conditioningWVTR
        {
            get { return _conditioningWVTR; }
            set { _conditioningWVTR = value; }
        }
        public string conditioningOTR
        {
            get { return _conditioningOTR; }
            set { _conditioningOTR = value; }
        }
        public string testAreaWVTR
        {
            get { return _testAreaWVTR; }
            set { _testAreaWVTR = value; }
        }
        public string testAreaOTR
        {
            get { return _testAreaOTR; }
            set { _testAreaOTR = value; }
        }
        public string testGasSideWVTR
        {
            get { return _testGasSideWVTR; }
            set { _testGasSideWVTR = value; }
        }
        public string testGasSideOTR
        {
            get { return _testGasSideOTR; }
            set { _testGasSideOTR = value; }
        }
        public string o2WVTR
        {
            get { return _o2WVTR; }
            set { _o2WVTR = value; }
        }
        public string o2OTR
        {
            get { return _o2OTR; }
            set { _o2OTR = value; }
        }
        public string testOperatorWVTR
        {
            get { return _testOperatorWVTR; }
            set { _testOperatorWVTR = value; }
        }
        public string testOperatorOTR
        {
            get { return _testOperatorOTR; }
            set { _testOperatorOTR = value; }
        }
        public string labSampleId
        {
            get { return _labSampleId; }
            set { _labSampleId = value; }
        }
        public string sampling
        {
            get { return _sampling; }
            set { _sampling = value; }
        }
        public string samplingCondition
        {
            get { return _samplingCondition; }
            set { _samplingCondition = value; }
        }
        public string modelPTI
        {
            get { return _modelPTI; }
            set { _modelPTI = value; }
        }
        public DateTime calDueDatePTI
        {
            get { return _calDueDatePTI; }
            set { _calDueDatePTI = value; }
        }
        public string modelWVTR
        {
            get { return _modelWVTR; }
            set { _modelWVTR = value; }
        }
        public string srNoWVTR
        {
            get { return _srNoWVTR; }
            set { _srNoWVTR = value; }
        }
        public string calCerificateNoWVTR
        {
            get { return _calCerficateNoWVTR; }
            set { _calCerficateNoWVTR = value; }
        }
        public DateTime calCertificateDateWVTR
        {
            get { return _calCertificateDateWVTR; }
            set { _calCertificateDateWVTR = value; }
        }
        public DateTime calDueDateWVTR
        {
            get { return _calDueDateWVTR; }
            set { _calDueDateWVTR = value; }
        }
        public string calByWVTR
        {
            get { return _calByWVTR; }
            set { _calByWVTR = value; }
        }
        public string calAtWVTR
        {
            get { return _calAtWVTR; }
            set { _calAtWVTR = value; }
        }
        public string modelOTR
        {
            get { return _modelOTR; }
            set { _modelOTR = value; }
        }
        public string srNoOTR
        {
            get { return _srNoOTR; }
            set { _srNoOTR = value; }
        }
        public string calCerificateNoOTR
        {
            get { return _calCerficateNoOTR; }
            set { _calCerficateNoOTR = value; }
        }
        public DateTime calCertificateDateOTR
        {
            get { return _calCertificateDateOTR; }
            set { _calCertificateDateOTR = value; }
        }
        public DateTime calDueDateOTR
        {
            get { return _calDueDateOTR; }
            set { _calDueDateOTR = value; }
        }
        public string calByOTR
        {
            get { return _calByOTR; }
            set { _calByOTR = value; }
        }
        public string calAtOTR
        {
            get { return _calAtOTR; }
            set { _calAtOTR = value; }
        }
        public string sampleDescription
        {
            get { return _sampleDescription; }
            set { _sampleDescription = value; }
        }
        public DateTime testDateWVTR
        {
            get { return _testDateWVTR; }
            set { _testDateWVTR = value; }
        }
        public string testNoWVTR
        {
            get { return _testNoWVTR; }
            set { _testNoWVTR = value; }
        }
        public string gDayWVTR
        {
            get { return _gDayWVTR; }
            set { _gDayWVTR = value; }
        }
        public DateTime testDateOTR
        {
            get { return _testDateOTR; }
            set { _testDateOTR = value; }
        }
        public string testNoOTR
        {
            get { return _testNoOTR; }
            set { _testNoOTR = value; }
        }
        public string gDayOTR
        {
            get { return _gDayOTR; }
            set { _gDayOTR = value; }
        }
        public DateTime analysisStartingDate
        {
            get { return _analysisStartingDate; }
            set { _analysisStartingDate = value; }
        }
        public DateTime analysisCompleteDate
        {
            get { return _analysisCompletionDate; }
            set { _analysisCompletionDate = value; }
        }
        public string nameOfProduct
        {
            get { return _nameOfProduct; }
            set { _nameOfProduct = value; }
        }
        public string typeOfSample
        {
            get { return _typeOfSample; }
            set { _typeOfSample = value; }
        }
        public string InstrumentDetails
        {
            get { return _InstrumentDetails; }
            set { _InstrumentDetails = value; }
        }
        public string referenceMaterialDetails
        {
            get { return _referenceMaterialDetails; }
            set { _referenceMaterialDetails = value; }
        }
        public string dateOfMfg
        {
            get { return _dateOfMfg; }
            set { _dateOfMfg = value; }
        }
        public string dateOfExp
        {
            get { return _dateOfExp; }
            set { _dateOfExp = value; }
        }
        public string sampleQuality
        {
            get { return _sampleQuality; }
            set { _sampleQuality = value; }
        }
        public string testRequired
        {
            get { return _testRequired; }
            set { _testRequired = value; }
        }
        public string sampleCondition
        {
            get { return _sampleCondition; }
            set { _sampleCondition = value; }
        }
        public string samplingMethod
        {
            get { return _samplingMethod; }
            set { _samplingMethod = value; }
        }
        public string feedbackName
        {
            get { return _feedbackName; }
            set { _feedbackName = value; }
        }
        public string feedbackValue
        {
            get { return _feedbackValue; }
            set { _feedbackValue = value; }
        }
        public string customerRemark
        {
            get { return _customerRemark; }
            set { _customerRemark = value; }
        }
        public DateTime feedbackDate
        {
            get { return _feedbackDate; }
            set { _feedbackDate = value; }
        }
        public int feedbackWeightage
        {
            get { return _feedbackWeightage; }
            set { _feedbackWeightage = value; }
        }
        public string ScriptSample
        {
            get { return _ScriptSample; }
            set { _ScriptSample = value; }
        }
        public string testsRequested
        {
            get { return _testsRequested; }
            set { _testsRequested = value; }
        }
        public int CRFID
        {
            get { return _CRFID; }
            set { _CRFID = value; }
        }
        public string sampleConditionRemarks
        {
            get { return _sampleConditionRemarks; }
            set { _sampleConditionRemarks = value; }
        }
        public string SampleCheckListValue
        {
            get { return _SampleCheckListValue; }
            set { _SampleCheckListValue = value; }
        }
        public int SampleVerifiedBy
        {
            get { return _SampleVerifiedBy; }
            set { _SampleVerifiedBy = value; }
        }
        public string Temp
        {
            get { return _Temp; }
            set { _Temp = value; }
        }
        public string RH
        {
            get { return _RH; }
            set { _RH = value; }
        }
        public string WVTRResult
        {
            get { return _WVTRResult; }
            set { _WVTRResult = value; }
        }
        public string OTRResult
        {
            get { return _OTRResult; }
            set { _OTRResult = value; }
        }
        public string WVTRTestDate
        {
            get { return _WVTRTestDate; }
            set { _WVTRTestDate = value; }
        }
        public string OTRTestDate
        {
            get { return _OTRTestDate; }
            set { _OTRTestDate = value; }
        }
        public string WVTRTestNo
        {
            get { return _WVTRTestNo; }
            set { _WVTRTestNo = value; }
        }
        public string OTRTestNo
        {
            get { return _OTRTestNo; }
            set { _OTRTestNo = value; }
        }
        public int sampleCategoryID { get { return _sampleCategoryID; } set { _sampleCategoryID = value; } }
        public int CustomerCRFSampleID { get { return _CustomerCRFSampleID; } set { _CustomerCRFSampleID = value; } }
        public int CloneCRFSampleID { get { return _CloneCRFSampleID; } set { _CloneCRFSampleID = value; } }
        public int CRFStatusID { get { return _CRFStatusID; } set { _CRFStatusID = value; } }
        public string SampleType { get { return _SampleType; } set { _SampleType = value; } }

        public int AddCustomer(DAL.CM obj)
        {
            if (_sCon.State == System.Data.ConnectionState.Open)
                _sCon.Close();
            string sQuery = "insert into CustomerMaster(CustomerType,Status,CustomerUID)output INSERTED.CustomerMasterId values(@CustomerType,@Status,@CustomerUID)";
            using (SqlCommand cmd = new SqlCommand(sQuery, _sCon))
            {
                cmd.Parameters.AddWithValue("@CustomerType", obj._customerType);
                cmd.Parameters.AddWithValue("@Status", obj._status);
                cmd.Parameters.AddWithValue("@CustomerUID", obj.CustomerUID);
                _sCon.Open();
                int modified = (int)cmd.ExecuteScalar();

                if (_sCon.State == System.Data.ConnectionState.Open)
                    _sCon.Close();
                return modified;
            }
        }

        public int AddCustomerDetails(DAL.CM obj)
        {
            int modified = 0;
            if (_sCon.State == System.Data.ConnectionState.Open)
                _sCon.Close();
            string sQuery = "insert into CustomerDetails(CustomerMasterId,Title,FirstName,MiddleName,LastName,Created)output INSERTED.CustomerId values(@CustomerMasterId,@Title,@FirstName,@MiddleName,@LastName,@Created)";
            using (SqlCommand cmd = new SqlCommand(sQuery, _sCon))
            {
                cmd.Parameters.AddWithValue("@CustomerMasterId", obj.CustomerMasterId);
                cmd.Parameters.AddWithValue("@Title", obj.title);
                cmd.Parameters.AddWithValue("@FirstName", obj.firstName);
                cmd.Parameters.AddWithValue("@MiddleName", obj.middleName);
                cmd.Parameters.AddWithValue("@LastName", obj.lastName);
                cmd.Parameters.AddWithValue("@Created", DateTime.Now);
                _sCon.Open();
                modified = (int)cmd.ExecuteScalar();

                if (_sCon.State == System.Data.ConnectionState.Open)
                    _sCon.Close();
                return modified;
            }
        }

        public int AddGroupDetails(DAL.CM obj)
        {
            int modified = 0;
            if (_sCon.State == System.Data.ConnectionState.Open)
                _sCon.Close();
            string sQuery = "insert into GroupDetails(CustomerMasterId,GroupName,Status)output INSERTED.GroupId values(@CustomerMasterId,@GroupName,@Status)";
            using (SqlCommand cmd = new SqlCommand(sQuery, _sCon))
            {
                cmd.Parameters.AddWithValue("@CustomerMasterId", obj.CustomerMasterId);
                cmd.Parameters.AddWithValue("@GroupName", obj.GroupName);
                cmd.Parameters.AddWithValue("@Status", obj.status);
                _sCon.Open();
                modified = (int)cmd.ExecuteScalar();

                if (_sCon.State == System.Data.ConnectionState.Open)
                    _sCon.Close();
                return modified;
            }
        }

        public int AddCompanyDetails(DAL.CM obj)
        {
            int modified = 0;
            if (_sCon.State == System.Data.ConnectionState.Open)
                _sCon.Close();
            string sQuery = "insert into CompanyDetails(CustomerMasterId,GroupId,CompanyName,TradingName,Created)output INSERTED.CompanyID values(@CustomerMasterId,@GroupId,@CompanyName,@TradingName,@Created)";
            using (SqlCommand cmd = new SqlCommand(sQuery, _sCon))
            {
                cmd.Parameters.AddWithValue("@CustomerMasterId", obj.CustomerMasterId);
                cmd.Parameters.AddWithValue("@GroupId", obj.groupId);
                cmd.Parameters.AddWithValue("@CompanyName", obj.CompanyName);
                cmd.Parameters.AddWithValue("@TradingName", obj.TradingName);
                cmd.Parameters.AddWithValue("@Created", DateTime.Now);
                _sCon.Open();
                modified = (int)cmd.ExecuteScalar();

                if (_sCon.State == System.Data.ConnectionState.Open)
                    _sCon.Close();
                return modified;
            }
        }
        public int AddLocationDetails(DAL.CM obj)
        {
            int modified = 0;
            if (_sCon.State == System.Data.ConnectionState.Open)
                _sCon.Close();
            string sQuery = "insert into LocationDetails(CustomerMasterId,CustomerId,CustomerType,Location,LocationName,AddressLine1,AddressLine2,AddressLine3,Country,State,District,Taluka,City,Suburb,Pincode,Status,LocationAddressType) values(@CustomerMasterId,@CustomerId,@CustomerType,@Location,@LocationName,@AddressLine1,@AddressLine2,@AddressLine3,@Country,@State,@District,@Taluka,@City,@Suburb,@Pincode,@Status,@LocationAddressType)";
            using (SqlCommand cmd = new SqlCommand(sQuery, _sCon))
            {
                cmd.Parameters.AddWithValue("@CustomerMasterId", obj.CustomerMasterId);
                cmd.Parameters.AddWithValue("@CustomerId", obj.customerId);
                cmd.Parameters.AddWithValue("@CustomerType", obj.customerType);
                cmd.Parameters.AddWithValue("@Location", obj.location);
                cmd.Parameters.AddWithValue("@LocationName", obj.locationName);
                cmd.Parameters.AddWithValue("@AddressLine1", obj.addressLine1);
                cmd.Parameters.AddWithValue("@AddressLine2", obj.addressLine2);
                cmd.Parameters.AddWithValue("@AddressLine3", obj.addressLine3);
                cmd.Parameters.AddWithValue("@Country", obj.country);
                cmd.Parameters.AddWithValue("@State", obj.state);
                cmd.Parameters.AddWithValue("@District", obj.district);
                cmd.Parameters.AddWithValue("@Taluka", obj.taluka);
                cmd.Parameters.AddWithValue("@City", obj.city);
                cmd.Parameters.AddWithValue("@Suburb", obj.suburb);
                cmd.Parameters.AddWithValue("@Pincode", obj.pincode);
                cmd.Parameters.AddWithValue("@Status", obj.status);
                cmd.Parameters.AddWithValue("@LocationAddressType", obj.locationAddressType);
                _sCon.Open();
                cmd.ExecuteScalar();

                if (_sCon.State == System.Data.ConnectionState.Open)
                    _sCon.Close();
                return modified;
            }
        }

        public int AddContactDetails(DAL.CM obj)
        {
            int modified = 0;
            if (_sCon.State == System.Data.ConnectionState.Open)
                _sCon.Close();
            string sQuery = "insert into ContactDetails (CustomerMasterId,CustomerId,CustomerType,PersonId,Mobile,Email,Phone,Fax) values (@CustomerMasterId,@CustomerId,@CustomerType,@PersonId,@CustomerMobile,@CustomerEmail,@CustomerPhone,@CustomerFax)";
            using (SqlCommand cmd = new SqlCommand(sQuery, _sCon))
            {

                cmd.Parameters.AddWithValue("@CustomerMasterId", obj.CustomerMasterId);
                cmd.Parameters.AddWithValue("@CustomerId", obj.customerId);
                cmd.Parameters.AddWithValue("@CustomerType", obj.customerType);
                cmd.Parameters.AddWithValue("@PersonId", obj.personId);
                cmd.Parameters.AddWithValue("@CustomerMobile", obj.mobile);
                cmd.Parameters.AddWithValue("@CustomerEmail", obj.email);
                cmd.Parameters.AddWithValue("@CustomerPhone", obj.phone);
                cmd.Parameters.AddWithValue("@CustomerFax", obj.fax);
                _sCon.Open();
                cmd.ExecuteScalar();

                if (_sCon.State == System.Data.ConnectionState.Open)
                    _sCon.Close();
                return modified;
            }
        }
        public int AddInquiryStatus(DAL.CM obj)
        {
            int modified = 0;
            if (_sCon.State == System.Data.ConnectionState.Open)
                _sCon.Close();
            string sQuery = "insert into InquiryStatus(StatusName)output INSERTED.InquiryStatusId values(@StatusName)";

            using (SqlCommand cmd = new SqlCommand(sQuery, _sCon))
            {
                cmd.Parameters.AddWithValue("@StatusName", obj.inquiryStatus);
                _sCon.Open();
                modified = (int)cmd.ExecuteScalar();

                if (_sCon.State == System.Data.ConnectionState.Open)
                    _sCon.Close();
                return modified;
            }
        }
        public int AddInquiryDetails(DAL.CM obj)
        {
            int modified = 0;
            if (_sCon.State == System.Data.ConnectionState.Open)
                _sCon.Close();
            string sQuery = "insert into CustomerInquiry(CustomerId,InquiryDetail,InquiryStatusID,Created,DepartmentID,productcategoryid)output INSERTED.InquiryId values (@CustomerId,@InquiryDetail,@InquiryStatusID,@Created,@DepartmentID,@productcategoryid)";
            using (SqlCommand cmd = new SqlCommand(sQuery, _sCon))
            {
                cmd.Parameters.AddWithValue("@CustomerId", obj.customerId);
                cmd.Parameters.AddWithValue("@InquiryDetail", obj.inquiry);
                cmd.Parameters.AddWithValue("@InquiryStatusID", obj.inquiryStatusId);
                cmd.Parameters.AddWithValue("@Created", obj.created);
                cmd.Parameters.AddWithValue("@DepartmentID", obj.employeeDepartmentID);
                cmd.Parameters.AddWithValue("@productcategoryid", obj.subgroupid);
                _sCon.Open();
                modified = (int)cmd.ExecuteScalar();

                if (_sCon.State == System.Data.ConnectionState.Open)
                    _sCon.Close();
                return modified;
            }
        }
        public int AddPersonDetails(DAL.CM obj)
        {
            int modified = 0;
            if (_sCon.State == System.Data.ConnectionState.Open)
                _sCon.Close();
            string sQuery = "insert into ContactPersonDetails(CustomerMasterId,CustomerType,Title,FirstName,MiddleName,LastName,Designation,Department)output INSERTED.PersonId values(@CustomerMasterId,@CustomerType,@Title,@FirstName,@MiddleName,@LastName,@Designation,@Department)";
            using (SqlCommand cmd = new SqlCommand(sQuery, _sCon))
            {
                cmd.Parameters.AddWithValue("@CustomerMasterId", obj.CustomerMasterId);
                cmd.Parameters.AddWithValue("@CustomerType", obj.customerType);
                cmd.Parameters.AddWithValue("@Title", obj.title);
                cmd.Parameters.AddWithValue("@FirstName", obj.firstName);
                cmd.Parameters.AddWithValue("@MiddleName", obj.middleName);
                cmd.Parameters.AddWithValue("@LastName", obj.lastName);
                cmd.Parameters.AddWithValue("@Designation", obj.designation);
                cmd.Parameters.AddWithValue("@Department", obj.department);
                _sCon.Open();
                modified = (int)cmd.ExecuteScalar();

                if (_sCon.State == System.Data.ConnectionState.Open)
                    _sCon.Close();
                return modified;
            }
        }
        public int AddCustomerRequest(DAL.CM obj)
        {
            int modified = 0;
            if (_sCon.State == System.Data.ConnectionState.Open)
                _sCon.Close();
            string sQuery = "Insert into CustomerRequestDetails(InquiryId,CustomerId,ContactPerson,ShippingAgency,AirwayBillNo,RequestTypeId,Created)output INSERTED.CustomerRequestId values (@InquiryId,@CustomerId,@ContactPerson,@ShippingAgency,@AirwayBillNo,@RequestTypeId,@Created)";
            using (SqlCommand cmd = new SqlCommand(sQuery, _sCon))
            {
                cmd.Parameters.AddWithValue("@InquiryId", obj.inquiryId);
                cmd.Parameters.AddWithValue("@CustomerId", obj.customerId);
                cmd.Parameters.AddWithValue("@ContactPerson", obj.personId);
                cmd.Parameters.AddWithValue("@ShippingAgency", obj.shippingAgency);
                cmd.Parameters.AddWithValue("@AirwayBillNo", obj.airwayBillNo);
                cmd.Parameters.AddWithValue("@RequestTypeId", obj.requestTypeId);
                cmd.Parameters.AddWithValue("@Created", DateTime.Now);
                _sCon.Open();
                modified = (int)cmd.ExecuteScalar();

                if (_sCon.State == System.Data.ConnectionState.Open)
                    _sCon.Close();
                return modified;
            }
        }
        public int AddCustomerCRFSampleDetails(DAL.CM obj)
        {
            int modified = 0;
            if (_sCon.State == System.Data.ConnectionState.Open)
                _sCon.Close();
            string sQuery = "insert into CustomerCRFSampleDetails (InquiryId,CustomerRequestId,CustomerId,SampleName,SampleType,BatchNo,TestMethod,TestParameter,Specification,SizeOfSample,Remarks,Created,CRFID) values (@InquiryId,@CustomerRequestId,@CustomerId,@SampleName,@SampleType,@BatchNo,@TestMethod,@TestParameter,@Specification,@SizeOfSample,@Remarks,@Created,@CRFID)";
            using (SqlCommand cmd = new SqlCommand(sQuery, _sCon))
            {
                cmd.Parameters.AddWithValue("@InquiryId", obj.inquiryId);
                cmd.Parameters.AddWithValue("@CustomerRequestId", obj.customerRequestId);
                cmd.Parameters.AddWithValue("@CustomerId", obj.customerId);
                cmd.Parameters.AddWithValue("@SampleName", obj.sampleName);
                cmd.Parameters.AddWithValue("@SampleType", obj.SampleType);
                cmd.Parameters.AddWithValue("@BatchNo", obj.batchNo);
                cmd.Parameters.AddWithValue("@TestMethod", obj.testMethod);
                cmd.Parameters.AddWithValue("@TestParameter", obj.testParameter);
                cmd.Parameters.AddWithValue("@Specification", obj.specification);
                cmd.Parameters.AddWithValue("@SizeOfSample", obj.sizeOfSample);
                cmd.Parameters.AddWithValue("@Remarks", obj.remarks);
                cmd.Parameters.AddWithValue("@CRFID", obj.CRFID);
                cmd.Parameters.AddWithValue("@Created", DateTime.Now);
                _sCon.Open();
                cmd.ExecuteScalar();

                if (_sCon.State == System.Data.ConnectionState.Open)
                    _sCon.Close();
                return modified;
            }
        }
        public int AddCustomerSampleDetailsMocon(DAL.CM obj)
        {
            int modified = 0;
            if (_sCon.State == System.Data.ConnectionState.Open)
                _sCon.Close();
            string sQuery = "insert into CustomerCRFSampleDetails (InquiryId,CustomerRequestId,CustomerId,SampleName,DescriptionOfTest,TestMethod,TestParameter,ExpectedValue,Dimensions,SizeOfSample,Remarks,Created,CRFID) values (@InquiryId,@CustomerRequestId,@CustomerId,@SampleName,@Description,@TestMethod,@TestParameter,@ExpectedValue,@Dimensions,@SizeOfSample,@Remarks,@Created,@CRFID)";
            using (SqlCommand cmd = new SqlCommand(sQuery, _sCon))
            {
                cmd.Parameters.AddWithValue("@InquiryId", obj.inquiryId);
                cmd.Parameters.AddWithValue("@CustomerRequestId", obj.customerRequestId);
                cmd.Parameters.AddWithValue("@CustomerId", obj.customerId);
                cmd.Parameters.AddWithValue("@SampleName", obj.sampleName);
                cmd.Parameters.AddWithValue("@Description", obj.description);
                cmd.Parameters.AddWithValue("@TestMethod", obj.testMethod);
                cmd.Parameters.AddWithValue("@TestParameter", obj.testParameter);
                cmd.Parameters.AddWithValue("@ExpectedValue", obj.expectedValue);
                cmd.Parameters.AddWithValue("@Dimensions", obj.dimensions);
                cmd.Parameters.AddWithValue("@SizeOfSample", obj.sizeOfSample);
                cmd.Parameters.AddWithValue("@Remarks", obj.remarks);
                cmd.Parameters.AddWithValue("@CRFID", obj.CRFID);
                cmd.Parameters.AddWithValue("@Created", DateTime.Now);
                _sCon.Open();
                cmd.ExecuteScalar();

                if (_sCon.State == System.Data.ConnectionState.Open)
                    _sCon.Close();
                return modified;
            }
        }
        public int AddCustomerSampleDetailsPTI(DAL.CM obj)
        {
            int modified = 0;
            if (_sCon.State == System.Data.ConnectionState.Open)
                _sCon.Close();
            string sQuery = "insert into CustomerCRFSampleDetails (InquiryId,CustomerRequestId,CustomerId,SampleName,TestParameter,TestMethod,SizeOfSample,Remarks,Created,CRFID)output INSERTED.CustomerCRFSampleId values (@InquiryId,@CustomerRequestId,@CustomerId,@SampleName,@TestParameter,@TestMethod,@SizeOfSample,@Remarks,@Created,@CRFID)";
            using (SqlCommand cmd = new SqlCommand(sQuery, _sCon))
            {
                cmd.Parameters.AddWithValue("@InquiryId", obj.inquiryId);
                cmd.Parameters.AddWithValue("@CustomerRequestId", obj.customerRequestId);
                cmd.Parameters.AddWithValue("@CustomerId", obj.customerId);
                cmd.Parameters.AddWithValue("@SampleName", obj.sampleName);
                cmd.Parameters.AddWithValue("@TestParameter", obj.testParameter);
                cmd.Parameters.AddWithValue("@TestMethod", obj.testMethod);
                cmd.Parameters.AddWithValue("@SizeOfSample", obj.sizeOfSample);
                cmd.Parameters.AddWithValue("@Remarks", obj.remarks);
                cmd.Parameters.AddWithValue("@CRFID", obj.CRFID);
                cmd.Parameters.AddWithValue("@Created", DateTime.Now);
                _sCon.Open();
                modified = (int)cmd.ExecuteScalar();

                if (_sCon.State == System.Data.ConnectionState.Open)
                    _sCon.Close();
                return modified;
            }
        }
        public int AddCRFSampleDetails(DAL.CM obj)
        {
            int modified = 0;
            if (_sCon.State == System.Data.ConnectionState.Open)
                _sCon.Close();
            string sQuery = "insert into CRFSampleDetails (InquiryId,CustomerRequestId,CustomerId,SampleName,BatchNo,TestMethod,TestParameter,Specification,SizeOfSample,Remarks,Created,CRFID,CloneCRFSampleID) values (@InquiryId,@CustomerRequestId,@CustomerId,@SampleName,@BatchNo,@TestMethod,@TestParameter,@Specification,@SizeOfSample,@Remarks,@Created,@CRFID,@CloneCRFSampleID)";
            using (SqlCommand cmd = new SqlCommand(sQuery, _sCon))
            {
                cmd.Parameters.AddWithValue("@InquiryId", obj.inquiryId);
                cmd.Parameters.AddWithValue("@CustomerRequestId", obj.customerRequestId);
                cmd.Parameters.AddWithValue("@CustomerId", obj.customerId);
                cmd.Parameters.AddWithValue("@SampleName", obj.sampleName);
                cmd.Parameters.AddWithValue("@BatchNo", obj.batchNo);
                cmd.Parameters.AddWithValue("@TestMethod", obj.testMethod);
                cmd.Parameters.AddWithValue("@TestParameter", obj.testParameter);
                cmd.Parameters.AddWithValue("@Specification", obj.specification);
                cmd.Parameters.AddWithValue("@SizeOfSample", obj.sizeOfSample);
                cmd.Parameters.AddWithValue("@Remarks", obj.remarks);
                cmd.Parameters.AddWithValue("@Created", DateTime.Now);
                cmd.Parameters.AddWithValue("@CRFID", obj.CRFID);
                cmd.Parameters.AddWithValue("@CloneCRFSampleID", obj.CloneCRFSampleID);
                _sCon.Open();
                cmd.ExecuteScalar();

                if (_sCon.State == System.Data.ConnectionState.Open)
                    _sCon.Close();
                return modified;
            }
        }
        public int AddCustomerRequestMocon(DAL.CM obj)
        {
            int modified = 0;
            if (_sCon.State == System.Data.ConnectionState.Open)
                _sCon.Close();
            string sQuery = "Insert into CustomerRequestDetails(InquiryId,CustomerId,ContactPerson,ShippingAgency,AirwayBillNo,RequestTypeId,Created)output INSERTED.CustomerRequestId values (@InquiryId,@CustomerId,@ContactPerson,@ShippingAgency,@AirwayBillNo,@RequestTypeId,@Created)";
            using (SqlCommand cmd = new SqlCommand(sQuery, _sCon))
            {
                cmd.Parameters.AddWithValue("@InquiryId", obj.inquiryId);
                cmd.Parameters.AddWithValue("@CustomerId", obj.customerId);
                cmd.Parameters.AddWithValue("@ContactPerson", obj.personId);
                cmd.Parameters.AddWithValue("@ShippingAgency", obj.shippingAgency);
                cmd.Parameters.AddWithValue("@AirwayBillNo", obj.airwayBillNo);
                cmd.Parameters.AddWithValue("@RequestTypeId", obj.requestTypeId);
                cmd.Parameters.AddWithValue("@Created", DateTime.Now);
                _sCon.Open();
                modified = (int)cmd.ExecuteScalar();

                if (_sCon.State == System.Data.ConnectionState.Open)
                    _sCon.Close();
                return modified;
            }
        }
        public int AddSampleDetailsMocon(DAL.CM obj)
        {
            int modified = 0;
            if (_sCon.State == System.Data.ConnectionState.Open)
                _sCon.Close();
            string sQuery = "insert into CRFSampleDetails (InquiryId,CustomerRequestId,CustomerId,SampleName,DescriptionOfTest,TestMethod,TestParameter,ExpectedValue,Dimensions,SizeOfSample,Remarks,Created,CRFID,CloneCRFSampleID) values (@InquiryId,@CustomerRequestId,@CustomerId,@SampleName,@Description,@TestMethod,@TestParameter,@ExpectedValue,@Dimensions,@SizeOfSample,@Remarks,@Created,@CRFID,@CloneCRFSampleID)";
            using (SqlCommand cmd = new SqlCommand(sQuery, _sCon))
            {
                cmd.Parameters.AddWithValue("@InquiryId", obj.inquiryId);
                cmd.Parameters.AddWithValue("@CustomerRequestId", obj.customerRequestId);
                cmd.Parameters.AddWithValue("@CustomerId", obj.customerId);
                cmd.Parameters.AddWithValue("@SampleName", obj.sampleName);
                cmd.Parameters.AddWithValue("@Description", obj.description);
                cmd.Parameters.AddWithValue("@TestMethod", obj.testMethod);
                cmd.Parameters.AddWithValue("@TestParameter", obj.testParameter);
                cmd.Parameters.AddWithValue("@ExpectedValue", obj.expectedValue);
                cmd.Parameters.AddWithValue("@Dimensions", obj.dimensions);
                cmd.Parameters.AddWithValue("@SizeOfSample", obj.sizeOfSample);
                cmd.Parameters.AddWithValue("@Remarks", obj.remarks);
                cmd.Parameters.AddWithValue("@CRFID", obj.CRFID);
                cmd.Parameters.AddWithValue("@CloneCRFSampleID", obj.CloneCRFSampleID);
                cmd.Parameters.AddWithValue("@Created", DateTime.Now);
                _sCon.Open();
                cmd.ExecuteScalar();

                if (_sCon.State == System.Data.ConnectionState.Open)
                    _sCon.Close();
                return modified;
            }
        }
        public int AddSampleDetailsPTI(DAL.CM obj)
        {
            int modified = 0;
            if (_sCon.State == System.Data.ConnectionState.Open)
                _sCon.Close();
            string sQuery = "insert into CRFSampleDetails (InquiryId,CustomerRequestId,CustomerId,SampleName,TestParameter,TestMethod,SizeOfSample,Remarks,Created,CRFID)output INSERTED.CRFSampleId values (@InquiryId,@CustomerRequestId,@CustomerId,@SampleName,@TestParameter,@TestMethod,@SizeOfSample,@Remarks,@Created,@CRFID)";
            using (SqlCommand cmd = new SqlCommand(sQuery, _sCon))
            {
                cmd.Parameters.AddWithValue("@InquiryId", obj.inquiryId);
                cmd.Parameters.AddWithValue("@CustomerRequestId", obj.customerRequestId);
                cmd.Parameters.AddWithValue("@CustomerId", obj.customerId);
                cmd.Parameters.AddWithValue("@SampleName", obj.sampleName);
                cmd.Parameters.AddWithValue("@TestParameter", obj.testParameter);
                cmd.Parameters.AddWithValue("@TestMethod", obj.testMethod);
                cmd.Parameters.AddWithValue("@SizeOfSample", obj.sizeOfSample);
                cmd.Parameters.AddWithValue("@Remarks", obj.remarks);
                cmd.Parameters.AddWithValue("@CRFID", obj.CRFID);
                cmd.Parameters.AddWithValue("@Created", DateTime.Now);
                _sCon.Open();
                modified = (int)cmd.ExecuteScalar();

                if (_sCon.State == System.Data.ConnectionState.Open)
                    _sCon.Close();
                return modified;
            }
        }
        public int AddDescriptionDetails(DAL.CM obj)
        {
            int modified = 0;
            if (_sCon.State == System.Data.ConnectionState.Open)
                _sCon.Close();
            string sQuery = "insert into PTIDescriptionDetails (InquiryId,CustomerRequestId,CustomerId,sampleName,Description1,Description2,Description3,Created) values (@InquiryId,@CustomerRequestId,@CustomerId,@sampleName,@Description1,@Description2,@Description3,@Created)";

            using (SqlCommand cmd = new SqlCommand(sQuery, _sCon))
            {
                cmd.Parameters.AddWithValue("@InquiryId", obj.inquiryId);
                cmd.Parameters.AddWithValue("@CustomerRequestId", obj.customerRequestId);
                cmd.Parameters.AddWithValue("@CustomerId", obj.customerId);
                cmd.Parameters.AddWithValue("@sampleName", obj.sampleName);
                cmd.Parameters.AddWithValue("@Description1", obj.description);
                cmd.Parameters.AddWithValue("@Description2", obj.description2);
                cmd.Parameters.AddWithValue("@Description3", obj.description3);
                cmd.Parameters.AddWithValue("@Created", DateTime.Now);
                _sCon.Open();
                cmd.ExecuteScalar();

                if (_sCon.State == System.Data.ConnectionState.Open)
                    _sCon.Close();
                return modified;
            }
        }
        public int UpdateEmailAddress(DAL.CM obj)
        {
            if (_sCon.State == System.Data.ConnectionState.Open)
                _sCon.Close();
            string sQuery = "Update ContactDetails set Email='" + obj.email + "' where PersonId=" + obj.personId;
            _sCon.Open();
            SqlCommand cmd = new SqlCommand(sQuery, _sCon);
            int modified = cmd.ExecuteNonQuery();
            return modified;
        }
        public int UpdatePhoneNumber(DAL.CM obj)
        {
            if (_sCon.State == System.Data.ConnectionState.Open)
                _sCon.Close();
            string sQuery = "Update ContactDetails set Phone='" + obj.phone + "' where PersonId=" + obj.personId;
            _sCon.Open();
            SqlCommand cmd = new SqlCommand(sQuery, _sCon);
            int modified = cmd.ExecuteNonQuery();
            return modified;
        }
        public int UpdateMobileNumber(DAL.CM obj)
        {
            if (_sCon.State == System.Data.ConnectionState.Open)
                _sCon.Close();
            string sQuery = "Update ContactDetails set Mobile='" + obj.mobile + "' where PersonId=" + obj.personId;
            _sCon.Open();
            SqlCommand cmd = new SqlCommand(sQuery, _sCon);
            int modified = cmd.ExecuteNonQuery();
            return modified;
        }
        public int UpdateDepartment(DAL.CM obj)
        {
            if (_sCon.State == System.Data.ConnectionState.Open)
                _sCon.Close();
            string sQuery = "Update ContactPersonDetails set Department='" + obj.department + "' where PersonId='" + obj.personId + "'";
            _sCon.Open();
            SqlCommand cmd = new SqlCommand(sQuery, _sCon);
            int modified = cmd.ExecuteNonQuery();
            return modified;
        }
        public int UpdateDesignation(DAL.CM obj)
        {
            if (_sCon.State == System.Data.ConnectionState.Open)
                _sCon.Close();
            string sQuery = "Update ContactPersonDetails set Designation='" + obj.designation + "' where PersonId='" + obj.personId + "'";
            _sCon.Open();
            SqlCommand cmd = new SqlCommand(sQuery, _sCon);
            int modified = cmd.ExecuteNonQuery();
            return modified;
        }
        public int UpdateAddress(DAL.CM obj)
        {
            if (_sCon.State == System.Data.ConnectionState.Open)
                _sCon.Close();
            string sQuery = "Update LocationDetails set AddressLine1='" + obj.addressLine1 + "' where CustomerId='" + obj.customerId + "'";
            _sCon.Open();
            SqlCommand cmd = new SqlCommand(sQuery, _sCon);
            int modified = cmd.ExecuteNonQuery();
            return modified;
        }
        public int UpdateProfileAddress(DAL.CM obj)
        {
            if (_sCon.State == System.Data.ConnectionState.Open)
                _sCon.Close();
            string sQuery = "Update LocationDetails set AddressLine1='" + obj.addressLine1 + "', AddressLine2='" + obj.addressLine2 + "', AddressLine3='" + obj.addressLine3 + "', District='" + obj.district + "', State ='" + obj.state + "',Country='" + obj.country + "' where CustomerMasterId='" + obj.CustomerMasterId + "'";
            _sCon.Open();
            SqlCommand cmd = new SqlCommand(sQuery, _sCon);
            int modified = cmd.ExecuteNonQuery();
            return modified;
        }
        public int UpdateProfileContact(DAL.CM obj)
        {
            if (_sCon.State == System.Data.ConnectionState.Open)
                _sCon.Close();
            string sQuery = "Update ContactDetails set Mobile='" + obj.mobile + "', Email='" + obj.email + "', Phone='" + obj.phone + "' where CustomerMasterId='" + obj.CustomerMasterId + "'";
            _sCon.Open();
            SqlCommand cmd = new SqlCommand(sQuery, _sCon);
            int modified = cmd.ExecuteNonQuery();
            return modified;
        }
        public DataTable getCustomerDetails(int customerMasterID, string customerType)
        {
            if (customerType == "Individual")
            {
                sQuery = @"select c.*,l.* from customerdetails c inner join locationdetails l on c.CustomerMasterId = l.CustomerMasterId where c.customermasterid=" + customerMasterID;
            }
            else
            {
                sQuery = @"select c.*,l.* from companydetails c inner join locationdetails l on c.CustomerMasterId = l.CustomerMasterId where c.customermasterid=" + customerMasterID;
            }

            dt = GetDataUsingQuery(sQuery);
            return dt;
        }
        public DataTable getCustomerInquiryDetails(int InquiryID)
        {
            sQuery = @"select ci.inquiryid,cd.firstname + '' + cd.lastname as customername,d.DepartmentName, pg.ProductGroupName,p.subgroupname,
                                e.employeename,s.supervisorname,ci.created as EnquiryDate,(select top 1 issuedate from testresultdetails 
                                where sampleid=(select s.sampleid from sampledetails s inner join customerinquiry ci on s.id= ci.sampleid and ci.inquiryid=" + InquiryID + ") order by issuedate desc) as ReportDate " +
                               @" from customerdetails cd 
                                inner join customerinquiry ci on cd.customerid = ci.customerid 
                                inner join department d on d.departmentid=ci.departmentid
                                inner join ProductSubGroup p on ci.productCategoryID = p.SubGroupID  
                                inner join ProductGroup pg on p.productgroupid = pg.productgroupid
                                inner join sampledetails sp on sp.id = ci.sampleid
                                inner join allocation a on a.sampleid = ci.sampleid
                                inner join supervisor s on a.employeeid = s.employeeid 
                                inner join employees e on a.employeeid=e.employeeid
                                where ci.inquiryid=" + InquiryID +
                             @" union
                                select ci.inquiryid,cd.companyname as customername,d.DepartmentName, pg.ProductGroupName,p.subgroupname,
                                e.employeename,s.supervisorname,ci.created as EnquiryDate,(select top 1 issuedate from testresultdetails 
                                where sampleid=(select s.sampleid from sampledetails s inner join customerinquiry ci on s.id= ci.sampleid and ci.inquiryid=" + InquiryID + ") order by issuedate desc) as ReportDate " +
                            @"  from companydetails cd 
                                inner join customerinquiry ci on cd.companyid = ci.customerid 
                                inner join department d on d.departmentid=ci.departmentid
                                inner join ProductSubGroup p on ci.productCategoryID = p.SubGroupID  
                                inner join ProductGroup pg on p.productgroupid = pg.productgroupid
                                inner join sampledetails sp on sp.id = ci.sampleid
                                inner join allocation a on a.sampleid = ci.sampleid
                                inner join supervisor s on a.employeeid = s.employeeid 
                                inner join employees e on a.employeeid=e.employeeid
                                where ci.inquiryid=" + InquiryID;
            dt = GetDataUsingQuery(sQuery);
            return dt;
        }
        public DataTable getCustomerType(int customerMasterID)
        {
            sQuery = @"select * from CustomerMaster where customerMasterID=" + customerMasterID;
            dt = GetDataUsingQuery(sQuery);
            return dt;
        }
        public DataTable getContactDetails(int customerMasterID)
        {
            //sQuery = @"SELECT cp.title,cp.firstname,cp.middlename,cp.lastname, CASE when cd.contacttype = 'mobile' then cd.contactvalue END AS mobile
            //                , CASE when cd.contacttype = 'email' then cd.contactvalue END AS email
            //                , CASE when cd.contacttype = 'phone' then cd.contactvalue END AS phone
            //                FROM ContactDetails cd inner join contactpersondetails cp on cp.PersonId = cd.PersonId
            //                where ContactType IN ('mobile', 'email', 'phone') and cp.customermasterid=" + customerMasterID +
            //                " GROUP BY CustomerId,ContactType,contactvalue,title,firstname,middlename,lastname" +
            //                " ORDER BY CustomerId asc";
            //sQuery = @"select title,firstname,middlename,lastname,Mobile, Email, Phone
            //            from
            //            (
            //              select title,firstname,middlename,lastname,ContactValue, contacttype
            //              from ContactDetails cd inner join ContactPersonDetails cp on cp.PersonId = cd.PersonId 
            //              where cp.CustomerMasterId = " + customerMasterID +
            //           @") d
            //            pivot
            //            (
            //              max(ContactValue)
            //              for contacttype in (Mobile,Email,Phone)
            //            ) piv";
            sQuery = @"select distinct  title,firstname,middlename,lastname,Mobile, Email, Phone from ContactPersonDetails cp 
                            LEFT OUTER JOIN ContactDetails ci on cp.personid = ci.personid 
                            where ci.CustomerMasterId=" + customerMasterID;
            dt = GetDataUsingQuery(sQuery);
            return dt;
        }
        public DataTable getIndividualCustomerDetails()
        {
            sQuery = @"select distinct c.customermasterid,c.customerid,Title ,Firstname ,MiddleName ,Lastname, 
                                AddressLine1 + ' ' + AddressLine2 + ' ' + AddressLine3 as Address, country, state,district,city,pincode,LocationAddressType from customerdetails c 
                                inner join locationdetails l on c.customerid = l.CustomerId order by firstname asc";
            dt = GetDataUsingQuery(sQuery);
            return dt;
        }

        public DataTable getCompanyCustomerDetails()
        {
            sQuery = @"select c.customermasterid,c.companyid as CustomerId,c.companyname,c.tradingname,l.location,
                        AddressLine1 + ' ' + AddressLine2 + ' ' + AddressLine3 as Address, country, 
                        state,district,city,pincode,LocationAddressType
                        from companydetails c 
                        inner join locationdetails l on c.CompanyId = l.CustomerId 
                        GROUP BY c.customermasterid,c.companyid,companyname,tradingname,location,l.AddressLine1,l.AddressLine2,l.AddressLine3, country, state,district,city,pincode,
			            LocationAddressType ORDER BY companyname asc";
            dt = GetDataUsingQuery(sQuery);
            return dt;
        }
        public DataTable getCustomerDetails(string search, string customerType)
        {
            if (customerType == "Individual")
            {
                sQuery = @"select c.customermasterid,c.customerid,Title , Firstname , MiddleName , Lastname,
                            AddressLine1 + ' ' + AddressLine2 + ' ' + AddressLine3 + ' ' + country+ ' ' + state+ ' ' + district+ ' ' + city+ ' ' + pincode  as Address, 
                            LocationAddressType from customerdetails c inner join locationdetails l on c.customerid = l.CustomerId where c.firstname like '%" + search + "%' or c.middlename like '%" + search + "%' or c.lastname like '%" + search + "%'";
            }
            else
            {
                sQuery = @"select c.customermasterid,customerid,companyname,tradingname,location,AddressLine1 + ' ' + AddressLine2 + ' ' + AddressLine3 + ' ' + country+ ' ' + state+ ' ' + district+ ' ' + city+ ' ' + pincode  as Address, LocationAddressType from companydetails c inner join locationdetails l on c.CompanyId = l.CustomerId where companyname like '%" + search + "%'";
            }
            dt = GetDataUsingQuery(sQuery);
            return dt;
        }
        public DataTable getGroupDetails()
        {
            sQuery = @"select distinct * from GroupDetails";
            dt = GetDataUsingQuery(sQuery);
            return dt;
        }
        public DataTable getGroupDetails(int customerMasterID)
        {
            sQuery = @"select g.groupName from CompanyDetails c 
                        inner join groupDetails g on g.customermasterid = c.customermasterid
                        where g.customermasterid=" + customerMasterID;
            dt = GetDataUsingQuery(sQuery);
            return dt;
        }
        public DataTable getAllContactPersonDetails(int customerMasterID)
        {
            sQuery = "select* from ContactPersonDetails where CustomerMasterId = '" + customerMasterID + "' and personid not in (select personid from contactdetails)";
            dt = GetDataUsingQuery(sQuery);
            return dt;
        }
        public DataTable getInquiryDetails()
        {
            sQuery = @"select c.inquiryid,c.created,i.statusname, c.CustomerId,c.InquiryDetail,cd.CustomerMasterId,cd.FirstName as customername from InquiryStatus i 
                                    inner join CustomerInquiry c on i.InquiryStatusId = c.InquiryStatusId
									left join CRFCloneList cl on c.inquiryid = cl.enquiryid
                                    inner join CustomerDetails cd on c.CustomerId = cd.CustomerId
                                    union
                                    select c.inquiryid,c.created,i.statusname,c.CustomerId,c.InquiryDetail,cd.CustomerMasterId,cd.companyname as customername from InquiryStatus i 
                                    inner join CustomerInquiry c on i.InquiryStatusId = c.InquiryStatusId
									left join CRFCloneList cl on c.inquiryid = cl.enquiryid
                                    inner join companydetails cd on cd.companyid = c.CustomerId  order by c.inquiryid desc";
            dt = GetDataUsingQuery(sQuery);
            return dt;
        }
        public DataTable getInquiryDetails(int inquiryStatus)
        {
            sQuery = @"select c.inquiryid,c.created,i.statusname,c.CustomerId,c.InquiryDetail,cd.CustomerMasterId,cd.FirstName as customername,c.inquirystatusid from InquiryStatus i 
                                    inner join CustomerInquiry c on i.InquiryStatusId = c.InquiryStatusId
                                    inner join CustomerDetails cd on c.CustomerId = cd.CustomerId where c.inquirystatusid=" + inquiryStatus +
                                 @" union
                                    select c.inquiryid,c.created,i.statusname,c.CustomerId,c.InquiryDetail,cd.CustomerMasterId,cd.companyname as customername,c.inquirystatusid from InquiryStatus i 
                                    inner join CustomerInquiry c on i.InquiryStatusId = c.InquiryStatusId
                                    inner join companydetails cd on cd.companyid = c.CustomerId where c.inquirystatusid=" + inquiryStatus + " order by c.inquiryid desc";
            dt = GetDataUsingQuery(sQuery);
            return dt;
        }
        public DataTable getInquiryDetails(int InquiryID, int CRFType)
        {
            if (CRFType == 1 || CRFType == 3)
            {
                sQuery = @"select c.*,cr.ShippingAgency,cr.AirwayBillNo,cm.customeruid,cd.CustomerMasterId,cd.FirstName as customername,cp.personid,cr.contactperson 
                                    ,AddressLine1 + ' ' + AddressLine2 + ' ' + AddressLine3 as Address from InquiryStatus i 									
                                    inner join CustomerInquiry c on i.InquiryStatusId = c.InquiryStatusId
                                    inner join CustomerDetails cd on c.CustomerId = cd.CustomerId 
									inner join customermaster cm on cm.CustomerMasterId = cd.CustomerMasterId
									inner join ContactPersonDetails cp on cp.CustomerMasterId = cd.CustomerMasterId
                                    inner join LocationDetails lo on lo.customermasterid = cd.customermasterid
									inner join CustomerRequestDetails cr on cr.contactperson = cp.PersonId
									where c.inquiryid =" + InquiryID +
                                   @" union
                                    select c.*,cr.ShippingAgency,cr.AirwayBillNo,cm.customeruid,cd.CustomerMasterId,cd.companyname as customername, cp.personid,cr.ContactPerson
                                    ,AddressLine1 + ' ' + AddressLine2 + ' ' + AddressLine3 as Address from InquiryStatus i 									
                                    inner join CustomerInquiry c on i.InquiryStatusId = c.InquiryStatusId
                                    inner join companydetails cd on cd.companyid = c.CustomerId 
									inner join customermaster cm on cm.CustomerMasterId = cd.CustomerMasterId
									inner join ContactPersonDetails cp on cp.CustomerMasterId = cd.CustomerMasterId
                                    inner join LocationDetails lo on lo.customermasterid = cd.customermasterid
									inner join CustomerRequestDetails cr on cr.contactperson = cp.PersonId
									where c.inquiryid = " + InquiryID + " order by c.Created desc";
            }
            if (CRFType == 2)
            {
                sQuery = @"select c.*,cr.ShippingAgency,cr.AirwayBillNo,cm.customeruid,cd.CustomerMasterId,cd.FirstName as customername,cp.personid,cr.contactperson 
                                    ,AddressLine1 + ' ' + AddressLine2 + ' ' + AddressLine3 as Address from InquiryStatus i 									
                                    inner join CustomerInquiry c on i.InquiryStatusId = c.InquiryStatusId
                                    inner join CustomerDetails cd on c.CustomerId = cd.CustomerId 
									inner join customermaster cm on cm.CustomerMasterId = cd.CustomerMasterId
									inner join ContactPersonDetails cp on cp.CustomerMasterId = cd.CustomerMasterId
                                    inner join LocationDetails lo on lo.customermasterid = cd.customermasterid
									inner join CustomerRequestDetails cr on cr.contactperson = cp.PersonId
									where c.inquiryid =" + InquiryID +
                                   @" union
                                    select c.*,cr.ShippingAgency,cr.AirwayBillNo,cm.customeruid,cd.CustomerMasterId,cd.companyname as customername, cp.personid,cr.ContactPerson
                                    ,AddressLine1 + ' ' + AddressLine2 + ' ' + AddressLine3 as Address from InquiryStatus i 									
                                    inner join CustomerInquiry c on i.InquiryStatusId = c.InquiryStatusId
                                    inner join companydetails cd on cd.companyid = c.CustomerId 
									inner join customermaster cm on cm.CustomerMasterId = cd.CustomerMasterId
									inner join ContactPersonDetails cp on cp.CustomerMasterId = cd.CustomerMasterId
                                    inner join LocationDetails lo on lo.customermasterid = cd.customermasterid
									inner join CustomerRequestDetails cr on cr.contactperson = cp.PersonId
									where c.inquiryid = " + InquiryID + " order by c.Created desc";
            }
            dt = GetDataUsingQuery(sQuery);
            return dt;
        }
        public DataTable getInquiryDetails(string search)
        {
            sQuery = @"select c.inquiryid,c.created,i.statusname,c.CustomerId,c.InquiryDetail,cd.CustomerMasterId,cd.FirstName as customername from InquiryStatus i 
                                    inner join CustomerInquiry c on i.InquiryStatusId = c.InquiryStatusId
                                    inner join CustomerDetails cd on c.CustomerId = cd.CustomerId where cd.firstname like '%" + search + "%' or cd.middlename like '%" + search + "%' or cd.lastname like '%" + search + "%'" +
                                    "union " +
                                    "select c.inquiryid,c.created,i.statusname,c.CustomerId,c.InquiryDetail,cd.CustomerMasterId,cd.companyname as customername from InquiryStatus i " +
                                    "inner join CustomerInquiry c on i.InquiryStatusId = c.InquiryStatusId inner join companydetails cd on cd.companyid = c.CustomerId where companyname like '%" + search + "%'" +
                                    "order by c.Created desc";
            dt = GetDataUsingQuery(sQuery);
            return dt;
        }
        public DataTable BindInquiry()
        {
            sQuery = "Select * from CustomerInquiry where CustomerId in (select CustomerId from CustomerDetails union select companyid as customerid from companydetails)";
            dt = GetDataUsingQuery(sQuery);
            return dt;
        }
        public DataTable GetCustomerInquiryDetails()
        {
            DataTable dt = new DataTable();
            string sQuery = "Select * from CustomerInquiry";
            dt = GetDataUsingQuery(sQuery);
            return dt;
        }
        public DataTable[] GetCustomerInquiry()
        {
            string sQuery = "";

            DataTable dtNewInquiry = new DataTable();
            DataTable dtNewCustomer = new DataTable();
            DataTable dtAssigned = new DataTable();
            DataTable dtCompleted = new DataTable();

            int newInquiry = 1; int assignedInquiry = 19; int completedInquiry = 20;

            sQuery = @"select distinct ci.CustomerId from CustomerInquiry ci 
                            inner join customerdetails cd on cd.customerid = ci.CustomerId where cd.customerid 
                            not in(select customerid from customerrequestdetails)
                            union
                            select distinct ci.CustomerId as customerid from CustomerInquiry ci 
                            inner join companydetails cd on cd.companyid = ci.CustomerId  
                            where cd.companyid not in(select customerid from customerrequestdetails)";

            dtNewCustomer = GetDataUsingQuery(sQuery);

            string sQuery1 = @"Select inquiryid from CustomerInquiry ci 
                                inner join CustomerDetails cd on ci.CustomerId = cd.customerId where ci.InquiryStatusId = '";
            string sQuery2 = @"' union
                                Select inquiryid from CustomerInquiry ci 
                                inner join companydetails cd on ci.CustomerId = cd.companyid where ci.InquiryStatusId = '";

            sQuery = sQuery1 + newInquiry + sQuery2 + newInquiry + "'";
            dtNewInquiry = GetDataUsingQuery(sQuery);

            sQuery = sQuery1 + assignedInquiry + sQuery2 + assignedInquiry + "'";
            dtAssigned = GetDataUsingQuery(sQuery);

            sQuery = sQuery1 + completedInquiry + sQuery2 + completedInquiry + "'";
            dtCompleted = GetDataUsingQuery(sQuery);

            return new DataTable[] { dtNewInquiry, dtNewCustomer, dtAssigned, dtCompleted };
        }
        public DataTable GetNewCustomers()
        {
            DataTable dt = new DataTable();
            string sQuery = @"select distinct cd.CustomerId,cd.customermasterid,cd.FirstName + ' ' + cd.MiddleName + ' ' + cd.LastName as customername,
                                ld.AddressLine1 + ' ' + ld.AddressLine2 + ' ' + ld.AddressLine3 + ' ' + ld.city + ' ' + ld.Taluka + ' ' + ld.District + '-' + ld.Pincode + ',' + ld.State + '-' + ld.Country as Address
                                from CustomerInquiry ci 
                                inner join customerdetails cd on cd.customerid = ci.CustomerId  
                                left join locationdetails ld on ld.CustomerId = cd.CustomerId 
                                where cd.customerid not in(select customerid from customerrequestdetails)
                                union
                                select distinct cd.companyid,cd.customermasterid as customerid,cd.companyname as customername,
                                ld.AddressLine1 + ' ' + ld.AddressLine2 + ' ' + ld.AddressLine3 + ' ' + ld.city + ' ' + ld.Taluka + ' ' + ld.District + '-' + ld.Pincode + ',' + ld.State + '-' + ld.Country as Address
                                from CustomerInquiry ci 
                                inner join companydetails cd on cd.companyid = ci.CustomerId  
                                left join locationdetails ld on ld.CustomerId = cd.CompanyId 
                                where cd.companyid not in(select customerid from customerrequestdetails)";
            dt = GetDataUsingQuery(sQuery);
            return dt;
        }
        public DataTable GetNewCustomers(string search)
        {
            DataTable dt = new DataTable();
            string sQuery = @"select distinct cd.CustomerId,cd.customermasterid,cd.FirstName + ' ' + cd.MiddleName + ' ' + cd.LastName as customername,
                                ld.AddressLine1 + ' ' + ld.AddressLine2 + ' ' + ld.AddressLine3 + ' ' + ld.city + ' ' + ld.Taluka + ' ' + ld.District + '-' + ld.Pincode + ',' + ld.State + '-' + ld.Country as Address
                                from CustomerInquiry ci 
                                inner join customerdetails cd on cd.customerid = ci.CustomerId  
                                left join locationdetails ld on ld.CustomerId = cd.CustomerId 
                                where cd.customerid not in(select customerid from customerrequestdetails) and cd.FirstName like '%" + search + "%'" +
                             @" union
                                select distinct cd.companyid,cd.customermasterid as customerid,cd.companyname as customername,
                                ld.AddressLine1 + ' ' + ld.AddressLine2 + ' ' + ld.AddressLine3 + ' ' + ld.city + ' ' + ld.Taluka + ' ' + ld.District + '-' + ld.Pincode + ',' + ld.State + '-' + ld.Country as Address
                                from CustomerInquiry ci 
                                inner join companydetails cd on cd.companyid = ci.CustomerId  
                                left join locationdetails ld on ld.CustomerId = cd.CompanyId 
                                where cd.companyid not in(select customerid from customerrequestdetails) and cd.CompanyName like '%" + search + "%'";
            dt = GetDataUsingQuery(sQuery);
            return dt;
        }
        public DataTable GetCustomerID(int CustomerMasterId)
        {
            DataTable dt = new DataTable();
            string sQuery = @"select companyid as customerid from CompanyDetails where customermasterid = " + CustomerMasterId +
                            @"  union
                                select customerid from Customerdetails where customermasterid =" + CustomerMasterId;
            dt = GetDataUsingQuery(sQuery);
            return dt;
        }
        public DataTable[] GetCountForCustomerProfile(int customerID)
        {
            string sQuery = "";

            DataTable dtInquiry = new DataTable();
            DataTable dtSamples = new DataTable();
            DataTable dtCompleted = new DataTable();

            sQuery = "select inquiryid from customerinquiry ci where ci.CustomerId = " + customerID;
            dtInquiry = GetDataUsingQuery(sQuery);

            sQuery = @"select id from sampledetails sd inner join CustomerInquiry ci on sd.ID = ci.sampleID 
                        where ci.CustomerId = " + customerID;
            dtSamples = GetDataUsingQuery(sQuery);

            sQuery = @"select id from sampledetails sd inner join CustomerInquiry ci on sd.ID = ci.sampleID 
                        where ci.CustomerId = " + customerID + " and ci.InquiryStatusId=23";
            dtCompleted = GetDataUsingQuery(sQuery);

            return new DataTable[] { dtInquiry, dtSamples, dtCompleted };
        }
        public DataTable GetCustomerInquiryDetails(int SampleId)
        {
            DataTable dt = new DataTable();
            string sQuery = "Select * from CustomerInquiry ci inner join CRFcloneList cr on ci.inquiryid = cr.enquiryid where cr.SampleId='" + SampleId + "'";
            dt = GetDataUsingQuery(sQuery);
            return dt;
        }
        public DataTable GetCustomerInquiryDetails(int InquiryID, int number)
        {
            DataTable dt = new DataTable();
            string sQuery = "Select * from CustomerInquiry where InquiryID='" + InquiryID + "'";
            dt = GetDataUsingQuery(sQuery);
            return dt;
        }
        public DataTable BindContactPerson(int InquiryId)
        {
            sQuery = "select a.PersonId,(a.Title + ' ' + a.FirstName) as CustomerName from ContactPersonDetails a inner join CustomerDetails b on a.CustomerMasterId = b.CustomerMasterId inner join CustomerInquiry c on b.CustomerId = c.CustomerId where c.InquiryId = '" + InquiryId + "'union select a.PersonId,(a.Title + ' ' + a.FirstName) as CustomerName from ContactPersonDetails a inner join CompanyDetails b on a.CustomerMasterId = b.CustomerMasterId inner join CustomerInquiry c on b.CompanyId = c.CustomerId where c.InquiryId = '" + InquiryId + "'";
            dt = GetDataUsingQuery(sQuery);
            return dt;
        }
        public DataTable BindInquiryCustomer(int InquiryId)
        {
            sQuery = @"select ci.CustomerId,ci.InquiryId,ci.created,(cd.Title+' '+cd.firstname) as customername from customerdetails cd inner join CustomerInquiry ci on ci.CustomerId = cd.CustomerId where ci.InquiryId = '" + InquiryId + "' union select ci.CustomerId,ci.InquiryId,ci.created,cm.companyname as customername from companydetails cm inner join CustomerInquiry ci on ci.CustomerId = cm.CompanyId where ci.InquiryId = '" + InquiryId + "'";
            dt = GetDataUsingQuery(sQuery);
            return dt;
        }
        public DataTable BindCustomerContactPerson(int PersonId)
        {
            sQuery = @"Select cp.*,cd.*,ld.AddressLine1 from ContactDetails cd 
                        inner join LocationDetails ld on cd.CustomerId = ld.CustomerId 
                        inner join ContactPersonDetails cp on cd.PersonId = cp.PersonId
                        where cd.PersonId = '" + PersonId + "'";
            dt = GetDataUsingQuery(sQuery);
            return dt;
        }
        public DataTable getRequestDetails(int RequestNumber)
        {
            DataTable dt = new DataTable();
            string sQuery = @"Select cr.*,cd.FirstName + cd.LastName as CustomerName,l.AddressLine1 as address,c.CustomerUID from CustomerRequestDetails cr 
                            inner join CustomerDetails cd on cr.CustomerId = cd.CustomerId
                            inner join LocationDetails l on l.CustomerId = cd.CustomerId
							inner join CustomerMaster c on c.CustomerMasterId = cd.CustomerMasterId
                            where cr.CustomerRequestId = '" + RequestNumber + "' " +
                           @"union
                            Select cr.*,cm.CompanyName as CustomerName,l.AddressLine1 as address,c.CustomerUID from CustomerRequestDetails cr
                            inner join CompanyDetails cm on cr.CustomerId = cm.CompanyId
                            inner join LocationDetails l on l.CustomerId = cm.companyid
							inner join CustomerMaster c on c.CustomerMasterId = cm.CustomerMasterId
                            where cr.CustomerRequestId = '" + RequestNumber + "'";
            dt = GetDataUsingQuery(sQuery);
            return dt;
        }
        public DataTable getContactPersonDetails(int ContactPersonId)
        {
            DataTable dt = new DataTable();
            //   string sQuery = @"SELECT cp.title + ' ' + cp.firstname + cp.middlename as CustomerName ,cp.lastname, cp.department,cp.designation,  
            //CASE when cd.contacttype = 'mobile' then cd.contactvalue END AS mobile
            //                   , CASE when cd.contacttype = 'email' then cd.contactvalue END AS email
            //                   , CASE when cd.contacttype = 'phone' then cd.contactvalue END AS phone
            //                     FROM ContactDetails cd inner join contactpersondetails cp on cp.PersonId = cd.PersonId
            //                     where ContactType IN ('mobile', 'email', 'phone') and cp.personid= '" + ContactPersonId + "'" +
            //                   " GROUP BY CustomerId,ContactType,contactvalue,title,firstname,middlename,lastname,designation,department " +
            //                   " ORDER BY CustomerId asc";
            string sQuery = @"SELECT cp.title + ' ' + cp.firstname + cp.middlename as CustomerName ,cp.lastname, cp.department,cp.designation, cd.mobile,cd.phone,cd.email,cd.fax 
                              FROM ContactDetails cd inner join contactpersondetails cp on cp.PersonId = cd.PersonId
                              where cp.personid= " + ContactPersonId + " GROUP BY CustomerId,cd.mobile,cd.phone," +
                            @"cd.email,cd.fax,title,firstname,middlename,lastname,designation,department 
                                      ORDER BY CustomerId asc";
            dt = GetDataUsingQuery(sQuery);
            return dt;
        }
        public DataTable getCustomerCRFSampleDetails(int InquiryID)
        {
            DataTable dt = new DataTable();
            string sQuery = "select CustomerCRFSampleID,CustomerRequestID,SampleName,SampleType,BatchNo,TestMethod,TestParameter,DescriptionOfTest,ExpectedValue,Dimensions,Specification,SizeofSample,Remarks from CustomerCRFSampleDetails where InquiryId='" + InquiryID + "'";
            dt = GetDataUsingQuery(sQuery);
            return dt;
        }
        public DataTable getCRFSampleDetails(int InquiryID, int CloneCRFSampleID)
        {
            DataTable dt = new DataTable();
            string sQuery = "Select * from CRFSampleDetails where InquiryID='" + InquiryID + "' and CloneCRFSampleID=" + CloneCRFSampleID;
            dt = GetDataUsingQuery(sQuery);
            return dt;
        }
        public DataTable getSampleDetails(int SampleID)
        {
            DataTable dt = new DataTable();
            string sQuery = "Select * from SampleDetails sd inner join crfCloneList cl on cl.sampleid=sd.id where ID=" + SampleID;
            dt = GetDataUsingQuery(sQuery);
            return dt;
        }
        public DataTable getVerifierDetails(string SampleVerifiedBy)
        {
            DataTable dt = new DataTable();
            string sQuery = @"select * from sampledetails sd 
                                inner join employees e on e.ID = sd.sampleVerifiedBy 
                                where e.id='" + SampleVerifiedBy + "'";
            dt = GetDataUsingQuery(sQuery);
            return dt;
        }
        public DataTable getVerfierCustomerDetails(string InquiryID)
        {
            DataTable dt = new DataTable();
            string sQuery = @"select cd.customerid,cd.firstname + ' ' + cd.MiddleName + ' ' + cd.LastName as CustomerName from customerdetails cd
                                    inner join customerinquiry ci on ci.CustomerId = cd.CustomerId where ci.InquiryId = '" + InquiryID + "'" +
                                 @" union
                                    select cd.companyid as customerid,CompanyName as CustomerName from companydetails cd
                                    inner join customerinquiry ci on ci.CustomerId = cd.CompanyId
                                    where ci.InquiryId = '" + InquiryID + "'";
            dt = GetDataUsingQuery(sQuery);
            return dt;
        }
        public DataTable getAssignedSampleDetails(int SampleStatus)
        {
            DataTable dt = new DataTable();
            string sQuery = @"Select s.*,c.InquiryId,i.StatusName  from SampleDetails s 
                                inner join CustomerInquiry c on s.id = c.sampleID
                                inner join inquirystatus i on i.inquirystatusid = c.inquirystatusid 
                                where s.samplestatus=" + SampleStatus;
            dt = GetDataUsingQuery(sQuery);
            return dt;
        }
        public DataTable getSampleDetails(string SampleStatus)
        {
            DataTable dt = new DataTable();
            string sQuery = @"select distinct sd.sampleid,sd.ID,sd.sampleidseries,sd.receiveddate,sd.samplestatus,i.statusname 
                                from TestResults td 
                                inner join sampledetails sd on td.SampleId = sd.id 
                                inner join inquirystatus i on i.inquirystatusid=sd.SampleStatus
                                where sd.SampleStatus in(" + SampleStatus + ")";
            dt = GetDataUsingQuery(sQuery);
            return dt;
        }
        public DataTable getSampleDetailsForReportReview(string SampleStatus)
        {
            DataTable dt = new DataTable();
            string sQuery = @"select distinct CloneCRFSampleID,td.testresultid,sd.sampleid,td.testreportno,sd.sampleidseries,sd.receiveddate,sd.samplestatus,i.statusname,sd.ID 
                                from TestResultDetails td 
                                inner join sampledetails sd on td.SampleId = sd.id 
								inner join CRFCloneList c on c.sampleid = sd.id
                                inner join inquirystatus i on i.inquirystatusid=sd.SampleStatus
                                where sd.SampleStatus in(" + SampleStatus + ")";
            dt = GetDataUsingQuery(sQuery);
            return dt;
        }
        public DataTable getSampleDetailsForReportGeneration(string SampleStatus)
        {
            DataTable dt = new DataTable();
            string sQuery = @"select distinct sd.id,sd.sampleid,sd.sampleidseries,sd.receiveddate,sd.samplestatus,i.statusname 
                                from testresults td 
                                inner join sampledetails sd on td.SampleId = sd.id 
                                inner join inquirystatus i on i.inquirystatusid=sd.SampleStatus
                                where sd.SampleStatus in(" + SampleStatus + ")";
            dt = GetDataUsingQuery(sQuery);
            return dt;
        }
        public DataTable getSampleDetails(int inquiryStatusID, bool dummy)
        {
            DataTable dt = new DataTable();
            string sQuery = @"Select s.*,c.CloneCRFSampleID,c.enquiryId as inquiryID,i.StatusName  from SampleDetails s 
                                inner join CRFCloneList c on s.id = c.sampleID
                                inner join inquirystatus i on i.inquirystatusid = c.CRFStatusID and c.CRFStatusID = " + inquiryStatusID;
            dt = GetDataUsingQuery(sQuery);
            return dt;
        }
        public DataTable getCustomerPTISampleDetails(int RequestNumber)
        {
            DataTable dt = new DataTable();
            string sQuery = @"Select sd.SampleName,DescriptionOfTest,Description2,Description3,SizeOfSample,Remarks 
                                from Customercrfsampledetails sd 
                                inner join PTIDescriptionDetails pd on sd.inquiryid=pd.inquiryid where sd.inquiryid='" + RequestNumber + "' group by sd.inquiryid," +
                                "sd.SampleName,DescriptionOfTest,Description2,Description3,SizeOfSample,Remarks";
            dt = GetDataUsingQuery(sQuery);
            return dt;
        }
        public DataTable getPTISampleDetails(int RequestNumber)
        {
            DataTable dt = new DataTable();
            string sQuery = @"Select sd.SampleName,DescriptionOfTest,Description2,Description3,SizeOfSample,Remarks 
                                from crfsampledetails sd 
                                inner join PTIDescriptionDetails pd on sd.inquiryid=pd.inquiryid where sd.inquiryid='" + RequestNumber + "' group by sd.inquiryid," +
                                "sd.SampleName,DescriptionOfTest,Description2,Description3,SizeOfSample,Remarks";
            dt = GetDataUsingQuery(sQuery);
            return dt;
        }
        public DataTable GetSampleId(int EmployeeId)
        {
            DataTable dt = new DataTable();
            string sQuery = "Select sd.SampleId from Allocation a inner join SampleDetails sd on a.SampleId=sd.Id where a.EmployeeId='" + EmployeeId + "'";
            dt = GetDataUsingQuery(sQuery);
            return dt;
        }
        public DataTable GetCRFListForTestResults(int sampleID)
        {
            DataTable dt = new DataTable();
            string sQuery = @"select *,t.AnalysisStartingDate,t.AnalysisCompletionDate,t.DestroyDate,t.specification from crfsampledetails cd 
                                inner join crfclonelist ci on cd.clonecrfsampleid = ci.clonecrfsampleid
								inner join InquiryStatus s on s.inquirystatusid= ci.CRFStatusID
								left join testresults t on t.CRFSampleID = cd.CRFSampleId
                                inner join sampledetails sd on ci.sampleid= sd.id and sd.sampleid = " + sampleID;
            dt = GetDataUsingQuery(sQuery);
            return dt;
        }
        public DataTable GetCRFListForTestResultsMocon(string SampleIDSeries)
        {
            DataTable dt = new DataTable();
            string sQuery = @"select *,t.specification from crfsampledetails cd 
							    inner join CRFCloneList cr on cr.CloneCRFSampleID = cd.CloneCRFSampleID
								inner join InquiryStatus s on s.inquirystatusid= cr.CRFStatusID
								left join testresults t on t.CRFSampleID = cd.CRFSampleId
                                left join TestResultDetails tr on tr.sampleid = cr.sampleID
                                inner join sampledetails sd on cr.sampleid= sd.id and sd.sampleidseries in(" + SampleIDSeries + ")";
            dt = GetDataUsingQuery(sQuery);
            return dt;
        }
        public DataTable GetCRFListForAllocation(int sampleID)
        {
            DataTable dt = new DataTable();
            string sQuery = @"select * from crfsampledetails cd 
                                inner join CRFClonelist ci on cd.clonecrfsampleid = ci.clonecrfsampleid
								inner join InquiryStatus s on s.inquirystatusid= ci.CRFStatusID
                                inner join sampledetails sd on ci.sampleid= sd.id and sd.sampleid = '" + sampleID + "'";
            dt = GetDataUsingQuery(sQuery);
            return dt;
        }
        public DataTable getSampleIDFromCRFSampleID(int CRFSampleID)
        {
            DataTable dt = new DataTable();
            string sQuery = @"select cr.sampleID from CRFSampleDetails cf 
                                inner join CRFCloneList cr on cf.InquiryId = cr.EnquiryID
                                inner join SampleDetails sd on sd.id = cr.sampleID 
                                where cf.CRFSampleId = " + CRFSampleID;
            dt = GetDataUsingQuery(sQuery);
            return dt;
        }
        public DataTable GetCRFListForAllocationMocon(string SampleIDSeriesAll)
        {
            DataTable dt = new DataTable();
            string sQuery = @"select distinct a.allocationid,cd.BatchNo,cd.samplename,cd.TestMethod,cd.TestParameter,cd.testsrequested,cd.crfsampleid,sd.SampleIDSeries,TestParameter,td.AnalysisStartingDate,Temp,RH,WVTRResult,OTRResult,TestReportNo,cd.Specification,sd.sampleid as sampleUID from crfsampledetails cd 
                                inner join CRFClonelist c on cd.InquiryId = c.enquiryId
								inner join InquiryStatus s on s.inquirystatusid= c.CRFStatusID
								inner join allocation a on a.SampleId = c.sampleID
								left join testresults t on t.sampleID = c.sampleid
								left join testresultdetails td on td.sampleid = c.sampleid
                                inner join sampledetails sd on c.sampleid= sd.id and sd.sampleidseries in(" + SampleIDSeriesAll + ")";
            dt = GetDataUsingQuery(sQuery);
            return dt;
        }
        public int UpdateInquiryStatus(DAL.CM obj)
        {
            if (_sCon.State == System.Data.ConnectionState.Open)
                _sCon.Close();
            string sQuery = "Update CustomerInquiry set InquiryStatusId='" + obj.inquiryStatusId + "' where InquiryId='" + obj.inquiryId + "'";
            _sCon.Open();
            SqlCommand cmd = new SqlCommand(sQuery, _sCon);
            int modified = cmd.ExecuteNonQuery();
            return modified;
        }
        public int updateSampleStatus(DAL.CM obj)
        {
            if (_sCon.State == System.Data.ConnectionState.Open)
                _sCon.Close();
            string sQuery = "Update SampleDetails set SampleStatus='" + obj.sampleStatusID + "' where ID='" + obj.sampleId + "'";
            _sCon.Open();
            SqlCommand cmd = new SqlCommand(sQuery, _sCon);
            int modified = cmd.ExecuteNonQuery();
            return modified;
        }
        public DataTable getCRFList()
        {
            DataTable dt = new DataTable();
            string sQuery = "Select * from CRFList";
            dt = GetDataUsingQuery(sQuery);
            return dt;
        }
        public DataTable getCRFDetails(int InquiryID)
        {
            DataTable dt = new DataTable();
            string sQuery = "Select top 1 customerRequestID from CustomerRequestDetails where inquiryID=" + InquiryID + " order by created desc";
            dt = GetDataUsingQuery(sQuery);
            return dt;
        }
        public DataTable getCRFTypeDetails(int InquiryID)
        {
            DataTable dt = new DataTable();
            string sQuery = "select top 1 CRFID from CRFSampleDetails where inquiryid=" + InquiryID + " order by created desc";
            dt = GetDataUsingQuery(sQuery);
            return dt;
        }
        public DataTable getCRFByStatus(string CRFStatusID)
        {
            sQuery = @"select cr.clonecrfsampleID,c.inquiryid,i.statusname,c.created,i.statusname,c.CustomerId,c.InquiryDetail,cd.CustomerMasterId,cd.FirstName as customername from InquiryStatus i
                            left join CRFcloneList cr on i.InquiryStatusId = cr.CRFStatusID
                            inner join CustomerInquiry c on c.InquiryId = cr.enquiryID
                            inner join CustomerDetails cd on c.CustomerId = cd.CustomerId
                            where cr.CRFStatusID in (" + CRFStatusID + ")" +
                            @" union
                            select cr.clonecrfsampleID,c.inquiryid,i.statusname,c.created,i.statusname,c.CustomerId,c.InquiryDetail,cd.CustomerMasterId,cd.companyname as customername from InquiryStatus i
                            left join CRFcloneList cr on i.InquiryStatusId = cr.CRFStatusID
                            inner join CustomerInquiry c on c.InquiryId = cr.enquiryID
                            inner join CompanyDetails cd on c.CustomerId = cd.CompanyId
                            where cr.CRFStatusID in (" + CRFStatusID + ") order by c.Created desc";
            dt = GetDataUsingQuery(sQuery);
            return dt;
        }
        public DataTable getCRFByStatus(string CRFStatusID, string search)
        {
            sQuery = @"select cr.clonecrfsampleID,c.inquiryid,i.statusname,c.created,i.statusname,c.CustomerId,c.InquiryDetail,cd.CustomerMasterId,cd.FirstName as customername from InquiryStatus i
                            inner join CustomerInquiry c on i.InquiryStatusId = c.InquiryStatusId
                            left join CRFcloneList cr on c.inquiryid = cr.enquiryid
                            inner join customerinquiry ci on cr.enquiryid = ci.inquiryid
                            inner join CustomerDetails cd on c.CustomerId = cd.CustomerId 
                            inner join CRFSampleDetails cs on cs.inquiryid = c.inquiryid
                            where cd.firstname like '%" + search + "%' or cd.middlename like '%" + search + "%' or cd.lastname like '%" + search + "%' and c.inquirystatusid in(" + CRFStatusID + ")" +
                            @" union
                            select cr.clonecrfsampleID,c.inquiryid,i.statusname,c.created,i.statusname,c.CustomerId,c.InquiryDetail,cd.CustomerMasterId,cd.companyname as customername from InquiryStatus i
                            inner join CustomerInquiry c on i.InquiryStatusId = c.InquiryStatusId
                            left join CRFcloneList cr on c.inquiryid = cr.enquiryid
                            inner join customerinquiry ci on cr.enquiryid = ci.inquiryid
                            inner join CompanyDetails cd on c.CustomerId = cd.CompanyId 
                            inner join CRFSampleDetails cs on cs.inquiryid = c.inquiryid
                            where companyname like '%" + search + "%' and c.inquirystatusid in(" + CRFStatusID + ")" +
                            "order by c.Created desc";
            dt = GetDataUsingQuery(sQuery);
            return dt;
        }
        public int generateCustomerUID()
        {
            Random rand = new System.Random();
            int CustomerUID = rand.Next(10000000, 100000000);//random.Next(1, 500000);
            return CustomerUID;
        }
        public DataTable checkCompanyNameExists(string CompanyName)
        {
            sQuery = @"select * from companydetails where companyname = '" + CompanyName + "'";
            dt = GetDataUsingQuery(sQuery);
            return dt;
        }

        public int checkCustomerUIDExists(int CustomerUID)
        {
            string ErrMsg = string.Empty;
            try
            {
                if (_sCon.State != ConnectionState.Open)
                {
                    _sCon.Open();
                }
                sQuery = "SELECT count(*) FROM CustomerMaster WHERE CustomerUID = " + CustomerUID;
                SqlCommand cmd = new SqlCommand(sQuery, _sCon);
                int exists = Convert.ToInt32(cmd.ExecuteScalar());
                return exists;
            }
            catch (Exception ex)
            {
                ErrMsg = ex.Message;
                HttpContext.Current.Response.Redirect("~/Error.aspx", false);
                return 0;
            }
        }
        public int checkEmployeeExists(string EmployeeName)
        {
            string ErrMsg = string.Empty;
            try
            {
                if (_sCon.State != ConnectionState.Open)
                {
                    _sCon.Open();
                }
                sQuery = "SELECT count(*) FROM Employees WHERE EmployeeName = '" + EmployeeName + "'";
                SqlCommand cmd = new SqlCommand(sQuery, _sCon);
                int exists = Convert.ToInt32(cmd.ExecuteScalar());
                return exists;
            }
            catch (Exception ex)
            {
                ErrMsg = ex.Message;
                HttpContext.Current.Response.Redirect("~/Error.aspx", false);
                return 0;
            }
        }
        public DataTable getAllCustomers()
        {
            string sQuery = "select CustomerId, (FirstName +' '+ LastName) as CustomerName from CustomerDetails union select CompanyId as CustomerId,CompanyName as CustomerName from CompanyDetails order by customername asc";
            dt = GetDataUsingQuery(sQuery);
            return dt;
        }
        public DataTable getAllDepartments()
        {
            string sQuery = "Select * from SubDepartment";
            dt = GetDataUsingQuery(sQuery);
            return dt;
        }
        public DataTable getAllRoles()
        {
            string sQuery = "Select * from Roles";
            dt = GetDataUsingQuery(sQuery);
            return dt;
        }
        public DataTable getRoleMenuList(int RoleID)
        {
            string sQuery = "select * from Roles where Roleid=" + RoleID;
            dt = GetDataUsingQuery(sQuery);
            return dt;
        }
        public DataTable getMenuItems(string MenuIDList)
        {
            string sQuery = "select * from MenuItems where menuid in (" + MenuIDList + ")";
            dt = GetDataUsingQuery(sQuery);
            return dt;
        }
        public DataTable getProductCategories()
        {
            string sQuery = "Select * from productsubgroup order by subgroupname asc";
            dt = GetDataUsingQuery(sQuery);
            return dt;
        }
        public int AddProductGroup(DAL.CM obj)
        {
            int modified = 0;
            if (_sCon.State == System.Data.ConnectionState.Open)
                _sCon.Close();
            string sQuery = "";
            sQuery = @"Select * from ProductGroup where ProductGroupName='" + obj.GroupName + "'";
            dt = GetDataUsingQuery(sQuery);
            if (dt.Rows.Count > 0)
            {
                modified = 0;
            }
            else
            {
                sQuery = "insert into ProductGroup (ProductGroupName,DepartmentId) output INSERTED.ProductGroupID values (@ProductGroupName,@DepartmentId)";

                using (SqlCommand cmd = new SqlCommand(sQuery, _sCon))
                {
                    cmd.Parameters.AddWithValue("@ProductGroupName", obj.GroupName);
                    cmd.Parameters.AddWithValue("@DepartmentId", obj.departmentID);
                    modified = (int)cmd.ExecuteScalar();

                    if (_sCon.State == System.Data.ConnectionState.Open)
                        _sCon.Close();
                }
            }
            return modified;
        }
        public int AddProductSubGroup(DAL.CM obj)
        {
            int modified = 0;
            if (_sCon.State == System.Data.ConnectionState.Open)
                _sCon.Close();
            string sQuery = "";
            sQuery = @"Select * from ProductSubGroup where SubGroupName='" + obj.subGroup + "'";
            dt = GetDataUsingQuery(sQuery);
            if (dt.Rows.Count > 0)
            {
                modified = 0;
            }
            else
            {
                sQuery = "insert into ProductSubGroup (SubGroupName,ProductGroupID,DepartmentId,sampleCategory) output INSERTED.ProductGroupID values (@SubGroupName,@ProductGroupID,@DepartmentId,@sampleCategory)";

                using (SqlCommand cmd = new SqlCommand(sQuery, _sCon))
                {
                    cmd.Parameters.AddWithValue("@SubGroupName", obj.subGroup);
                    cmd.Parameters.AddWithValue("@ProductGroupID", obj.groupId);
                    cmd.Parameters.AddWithValue("@DepartmentId", obj.departmentID);
                    cmd.Parameters.AddWithValue("@sampleCategory", obj.sampleCategoryID);
                    modified = (int)cmd.ExecuteScalar();

                    if (_sCon.State == System.Data.ConnectionState.Open)
                        _sCon.Close();
                }
            }
            return modified;
        }
        public DataTable getProductGroup(int DepartmentID)
        {
            string sQuery = "Select * from productGroup where DepartmentID=" + DepartmentID + " order by ProductGroupName asc";
            dt = GetDataUsingQuery(sQuery);
            return dt;
        }
        public DataTable getProductSubGroup(int GroupID)
        {
            string sQuery = "Select * from ProductSubGroup where ProductGroupID=" + GroupID + " order by SubGroupName asc";
            dt = GetDataUsingQuery(sQuery);
            return dt;
        }
        public DataTable GetProductCategory()
        {
            DataTable dt = new DataTable();
            string sQuery = "Select * from productsubgroup";
            dt = GetDataUsingQuery(sQuery);
            return dt;
        }
        public DataTable GetProductCategory(int InquiryID)
        {
            DataTable dt = new DataTable();
            string sQuery = @"Select * from CustomerInquiry ci 
                                inner join ProductSubGroup pc on ci.productcategoryid = pc.subgroupid
                                inner join ProductGroup pg on pg.ProductGroupID = pc.ProductGroupID 
                                where inquiryid = " + InquiryID;
            dt = GetDataUsingQuery(sQuery);
            return dt;
        }
        public DataTable GetProductCategoryDetails(string ProductCategory)
        {
            DataTable dt = new DataTable();
            string sQuery = "Select * from productsubgroup where subgroupid=" + ProductCategory;
            dt = GetDataUsingQuery(sQuery);
            return dt;
        }
        public DataTable GetProductGroupDetails(string ProductCategory)
        {
            DataTable dt = new DataTable();
            string sQuery = @"Select * from productsubgroup ps 
                                inner join productgroup pg on ps.ProductGroupID = pg.ProductGroupID 
                                where ps.subgroupid=" + ProductCategory;
            dt = GetDataUsingQuery(sQuery);
            return dt;
        }
        public DataTable GetEmployeeDetails()
        {
            DataTable dt = new DataTable();
            string sQuery = "Select * from Employees";
            dt = GetDataUsingQuery(sQuery);
            return dt;
        }
        public DataTable GetEmployeeDetails(int SupervisorID, bool val)
        {
            DataTable dt = new DataTable();
            string sQuery = @"Select * from orgtree o inner join employees e on o.id = e.id where o.PID=" + SupervisorID;
            dt = GetDataUsingQuery(sQuery);
            return dt;
        }
        public DataTable GetEmployeeDetails(int EmployeeID)
        {
            DataTable dt = new DataTable();
            string sQuery = "Select * from Employees where employeeid=" + EmployeeID;
            dt = GetDataUsingQuery(sQuery);
            return dt;
        }
        public DataTable GetEmployeeDetails(string DepartmentId, int EmployeeID)
        {
            DataTable dt = new DataTable();
            string sQuery = "select * from employees e inner join Supervisor s on e.employeeid = s.employeeid where e.employeeid=" + EmployeeID;
            dt = GetDataUsingQuery(sQuery);
            return dt;
        }
        public DataTable GetDepartmentSampleDetails(string DepartmentID)
        {
            DataTable dt = new DataTable();
            string sQuery = @"
Select s.*,cr.Clonecrfsampleid,cr.enquiryId as InquiryID,i.StatusName,c.departmentid  from SampleDetails s 
                                inner join CRFcloneList cr on s.id = cr.sampleID
								inner join customerinquiry c on c.InquiryId = cr.EnquiryID  
                                inner join inquirystatus i on i.inquirystatusid = cr.CRFStatusID
								inner join employeedepartment ed on ed.employeedepartmentid = c.departmentid
                                 where ed.employeedepartmentid in(" + DepartmentID + ")";
            dt = GetDataUsingQuery(sQuery);
            return dt;
        }
        public DataTable GetAllDepartmentSampleDetails()
        {
            DataTable dt = new DataTable();
            string sQuery = @"
Select s.*,cr.Clonecrfsampleid,cr.enquiryId as InquiryID,i.StatusName,c.departmentid  from SampleDetails s 
                                inner join CRFcloneList cr on s.id = cr.sampleID
								inner join customerinquiry c on c.InquiryId = cr.EnquiryID  
                                inner join inquirystatus i on i.inquirystatusid = cr.CRFStatusID
								inner join employeedepartment ed on ed.employeedepartmentid = c.departmentid ";
            dt = GetDataUsingQuery(sQuery);
            return dt;
        }
        public DataTable GetCustomerRequestDetails(string InquiryId)
        {
            DataTable dt = new DataTable();
            string sQuery = "select * from CustomerRequestDetails where InquiryId='" + InquiryId + "' order by Created desc";
            dt = GetDataUsingQuery(sQuery);
            return dt;
        }
        public DataTable GetAllocationDetails(int SampleId)
        {
            DataTable dt = new DataTable();
            string sQuery = "Select top 1 * from Allocation a inner join Employees e on a.employeeid = e.employeeid where SampleId='" + SampleId + "' order by a.created desc";
            dt = GetDataUsingQuery(sQuery);
            return dt;
        }
        public DataTable GetAllocationDetails(string AllocationID)
        {
            DataTable dt = new DataTable();
            string sQuery = "Select * from Allocation where AllocationId='" + AllocationID + "'";
            dt = GetDataUsingQuery(sQuery);
            return dt;
        }
        public DataTable GetAllocationFileDetails(int SampleId)
        {
            DataTable dt = new DataTable();
            string sQuery = @"select top 1 *,s.sampleID as sampleUID from allocation a 
                                inner join sampledetails s on a.sampleid = s.id
                                inner join crfclonelist c on c.sampleid = s.id 
                                inner join employees e on e.employeeid = a.employeeid where c.sampleID=" + SampleId + " order by a.created desc";
            dt = GetDataUsingQuery(sQuery);
            return dt;
        }
        public DataTable GetAllocation(int EmployeeId, int roleID)
        {
            DataTable dt = new DataTable();
            string sQuery = "";
            switch (roleID)
            {
                case 2:
                    sQuery = @"select c.CloneCRFSampleID,sd.SampleId,sd.sampleidseries,a.AllocationId,st.StatusName from Allocation a 
                                inner join SampleDetails sd on sd.Id = a.SampleId 
								inner join crfclonelist c on c.sampleid = sd.id 
								inner join InquiryStatus st on st.InquiryStatusId = c.CRFStatusID
                                inner join supervisor s on a.employeeid = s.employeeid and supervisorid=" + EmployeeId + " and st.StatusName='Allocated for Testing'" +
                             @" union
                                Select sd.SampleId,sd.sampleidseries,a.AllocationId,st.StatusName from Allocation a 
                                inner join SampleDetails sd on sd.Id = a.SampleId 
								inner join crfclonelist c on c.sampleid = sd.id 
								inner join InquiryStatus st on st.InquiryStatusId = c.CRFStatusID where a.employeeid= " + EmployeeId + " and st.StatusName='Allocated for Testing'";
                    dt = GetDataUsingQuery(sQuery);
                    break;
                case 3:
                    sQuery = @"select c.CloneCRFSampleID,sd.SampleId,sd.sampleidseries,a.AllocationId,st.StatusName from Allocation a 
                                inner join SampleDetails sd on sd.Id = a.SampleId 
								inner join crfclonelist c on c.sampleid = sd.id 
								inner join InquiryStatus st on st.InquiryStatusId = c.CRFStatusID where a.employeeid='" + EmployeeId + "' and st.StatusName='Allocated for Testing'";
                    dt = GetDataUsingQuery(sQuery);
                    break;
                default: break;
            }
            return dt;
        }
        public DataTable GetSampleCheckList(string SampleCategory)
        {
            DataTable dt = new DataTable();
            string sQuery = "Select * from SampleChecklist where SampleCategory='" + SampleCategory + "'";
            dt = GetDataUsingQuery(sQuery);
            return dt;
        }
        public int AddAllocationDetails(DAL.CM obj)
        {
            int modified = 0;
            if (_sCon.State == System.Data.ConnectionState.Open)
                _sCon.Close();
            string sQuery = "insert into Allocation (EmployeeId,DepartmentId,SampleId,Created) output INSERTED.AllocationId values (@EmployeeId,@DepartmentId,@SampleId,@Created)";

            using (SqlCommand cmd = new SqlCommand(sQuery, _sCon))
            {
                cmd.Parameters.AddWithValue("@EmployeeId", obj.employeID);
                cmd.Parameters.AddWithValue("@DepartmentId", obj.department);
                cmd.Parameters.AddWithValue("@SampleId", obj.sampleId);
                cmd.Parameters.AddWithValue("@Created", DateTime.Now);
                _sCon.Open();
                modified = (int)cmd.ExecuteScalar();

                if (_sCon.State == System.Data.ConnectionState.Open)
                    _sCon.Close();
                return modified;
            }
        }
        public DataTable getSampleUID(int SampleID)
        {
            DataTable dt = new DataTable();
            //string sQuery = "select cr.*,cm.* from CustomerRequestDetails cr inner join CustomerDetails cd on cr.CustomerId = cd.CustomerId inner join CustomerMaster cm on cd.CustomerMasterId = cm.CustomerMasterId where cr.CustomerId = 28 union select cr.*,cm.* from CustomerRequestDetails cr inner join CompanyDetails cd on cr.CustomerId = cd.CompanyId inner join CustomerMaster cm on cd.CustomerMasterId = cm.CustomerMasterId where cr.CustomerId = 28";
            string sQuery = "Select * from SampleDetails where Id='" + SampleID + "'";
            dt = GetDataUsingQuery(sQuery);
            return dt;
        }
        public DataTable getSampleIDFromSampleUID(int SampleID)
        {
            DataTable dt = new DataTable();
            //string sQuery = "select cr.*,cm.* from CustomerRequestDetails cr inner join CustomerDetails cd on cr.CustomerId = cd.CustomerId inner join CustomerMaster cm on cd.CustomerMasterId = cm.CustomerMasterId where cr.CustomerId = 28 union select cr.*,cm.* from CustomerRequestDetails cr inner join CompanyDetails cd on cr.CustomerId = cd.CompanyId inner join CustomerMaster cm on cd.CustomerMasterId = cm.CustomerMasterId where cr.CustomerId = 28";
            string sQuery = @"Select * from SampleDetails sd inner join crfCloneList cl on cl.sampleid=sd.id where sd.SampleId='" + SampleID + "'";
            dt = GetDataUsingQuery(sQuery);
            return dt;
        }
        public DataTable getSampleIDFromSampleIDSeries(string SampleIDSeries)
        {
            DataTable dt = new DataTable();
            //string sQuery = "select cr.*,cm.* from CustomerRequestDetails cr inner join CustomerDetails cd on cr.CustomerId = cd.CustomerId inner join CustomerMaster cm on cd.CustomerMasterId = cm.CustomerMasterId where cr.CustomerId = 28 union select cr.*,cm.* from CustomerRequestDetails cr inner join CompanyDetails cd on cr.CustomerId = cd.CompanyId inner join CustomerMaster cm on cd.CustomerMasterId = cm.CustomerMasterId where cr.CustomerId = 28";
            string sQuery = "Select * from SampleDetails where SampleIdSeries='" + SampleIDSeries + "'";
            dt = GetDataUsingQuery(sQuery);
            return dt;
        }
        public int UpdateCRFCloneList(DAL.CM obj)
        {
            if (_sCon.State == System.Data.ConnectionState.Open)
                _sCon.Close();
            string sQuery = "Update CRFCloneList set SampleId='" + obj.sampleId + "', sampleHistory ='" + obj.sampleHistory + "' Where CloneCRFSampleID='" + obj.CloneCRFSampleID + "'";
            _sCon.Open();
            SqlCommand cmd = new SqlCommand(sQuery, _sCon);
            int modified = cmd.ExecuteNonQuery();
            return modified;
        }
        public int UpdateCRFStatus(DAL.CM obj)
        {
            if (_sCon.State == System.Data.ConnectionState.Open)
                _sCon.Close();
            string sQuery = "Update CRFCloneList set CRFStatusID='" + obj.CRFStatusID + "' Where CloneCRFSampleID='" + obj.CloneCRFSampleID + "'";
            _sCon.Open();
            SqlCommand cmd = new SqlCommand(sQuery, _sCon);
            int modified = cmd.ExecuteNonQuery();
            return modified;
        }
        public int AddSampleChecklistStatusDetails(DAL.CM obj)
        {
            int modified = 0;
            if (_sCon.State == System.Data.ConnectionState.Open)
                _sCon.Close();
            string sQuery = "Insert into SampleChecklistStatus (SampleChecklistId,SampleId,SampleChecklistStatus,created,SampleChecklistValue)  values (@SampleChecklistId,@SampleId,@SampleChecklistStatus,@created,@SampleChecklistValue)";
            using (SqlCommand cmd = new SqlCommand(sQuery, _sCon))
            {
                cmd.Parameters.AddWithValue("@SampleChecklistId", obj.sampleChecklistId);
                cmd.Parameters.AddWithValue("@SampleId", obj.sampleId);
                cmd.Parameters.AddWithValue("@SampleChecklistStatus", obj.sampleChecklistStatus);
                cmd.Parameters.AddWithValue("@Created", DateTime.Now);
                cmd.Parameters.AddWithValue("@SampleChecklistValue", obj.SampleCheckListValue);
                _sCon.Open();
                cmd.ExecuteScalar();
                if (_sCon.State == System.Data.ConnectionState.Open)
                    _sCon.Close();
                return modified;
            }
        }
        public int AddSampleDetails(DAL.CM obj)
        {
            int modified = 0;
            if (_sCon.State == System.Data.ConnectionState.Open)
                _sCon.Close();
            string sQuery = "Insert into SampleDetails (ReceivedDate,SampleStatus,SampleId,Created,SampleIDSeries,Remarks,SampleVerifiedBy) output INSERTED.Id values (@ReceivedDate,@SampleStatus,@SampleId,@Created,@SampleIDSeries,@Remarks,@SampleVerifiedBy)";
            using (SqlCommand cmd = new SqlCommand(sQuery, _sCon))
            {
                cmd.Parameters.AddWithValue("@ReceivedDate", obj.receivedDate);
                cmd.Parameters.AddWithValue("@SampleStatus", obj.inquiryStatusId);
                cmd.Parameters.AddWithValue("@SampleId", obj.sampleId);
                cmd.Parameters.AddWithValue("@Created", DateTime.Now);
                cmd.Parameters.AddWithValue("@SampleIDSeries", obj.sampleIDSeries);
                cmd.Parameters.AddWithValue("@Remarks", obj.sampleConditionRemarks);
                cmd.Parameters.AddWithValue("@SampleVerifiedBy", obj.SampleVerifiedBy);
                _sCon.Open();
                modified = (int)cmd.ExecuteScalar();

                if (_sCon.State == System.Data.ConnectionState.Open)
                    _sCon.Close();
                return modified;
            }
        }
        public DataTable GetCRFSample(string CloneCRFSampleID)
        {
            DataTable dt = new DataTable();
            string sQuery = @"select *,s.sampleID as sampleUID from allocation a 
                                inner join sampledetails s on a.sampleid = s.id
                                inner join crfclonelist c on c.sampleid = s.id 
								inner join crfsampledetails cs on cs.CloneCRFSampleID = c.CloneCRFSampleID
                                inner join employees e on e.employeeid = a.employeeid where c.CloneCRFSampleID='" + CloneCRFSampleID + "'";
            dt = GetDataUsingQuery(sQuery);
            return dt;
        }
        public DataTable GetCustomerCRFSample(string InquiryId)
        {
            DataTable dt = new DataTable();
            string sQuery = "Select * from CustomerCRFSampleDetails where InquiryId='" + InquiryId + "'";
            dt = GetDataUsingQuery(sQuery);
            return dt;
        }
        public DataTable getCRFcloneList(string InquiryId)
        {
            DataTable dt = new DataTable();
            string sQuery = "Select * from CRFcloneList where EnquiryId='" + InquiryId + "'";
            dt = GetDataUsingQuery(sQuery);
            return dt;
        }
        public DataTable GetCRFSamplePTI(int InquiryID)
        {
            DataTable dt = new DataTable();
            //string sQuery = @"Select ROW_NUMBER() OVER(ORDER BY c.crfsampleid ASC) AS Sr,pt.description1,pt.description2,
            //                        pt.description3, * from CRFSampleDetails c
            //                        inner join PTIDescriptionDetails pt on pt.InquiryId = c.InquiryId
            //                        where c.InquiryId='" + InquiryId + "'";
            string sQuery = @"Select distinct c.BatchNo,c.samplename,c.TestMethod,c.TestParameter,c.testsrequested,
									c.unitofmeasurement,c.Specification,
									sd.sampleIDSeries from CRFSampleDetails c
									inner join customerinquiry ci on ci.InquiryId = c.InquiryId 
									inner join SampleDetails sd on sd.id = ci.sampleID
                                    where c.InquiryId=" + InquiryID;
            dt = GetDataUsingQuery(sQuery);
            return dt;
        }
        public DataTable GetSampleCheckListStatusDetails(int SampleId)
        {
            DataTable dt = new DataTable();
            string sQuery = @"select ss.SampleCheckListStatus, ss.SampleCheckListValue,
                                CASE WHEN ss.SampleChecklistStatus = '1' THEN 'Pass' ELSE 'Fail' 
                                END AS Samplelist1,sc.SampleChecklistName from SampleChecklistStatus ss 
                                inner join SampleChecklist sc on ss.SampleChecklistId = sc.SampleChecklistId 
                                where SampleId='" + SampleId + "'";
            dt = GetDataUsingQuery(sQuery);
            return dt;
        }
        public DataTable GetChatDetails(string SampleId)
        {
            DataTable dt = new DataTable();
            string sQuery = "Select c.*,ed.EmployeeName from Chat c inner join Employees ed on c.EmployeeId=ed.employeeid  where SampleId='" + SampleId + "'";
            dt = GetDataUsingQuery(sQuery);
            return dt;
        }
        public int AddChat(DAL.CM obj)
        {
            int modified = 0;
            if (_sCon.State == System.Data.ConnectionState.Open)
                _sCon.Close();
            string sQuery = "Insert into Chat (SampleId,EmployeeId,Message,Date)  values (@SampleId,@EmployeeId,@Message,@Date)";
            using (SqlCommand cmd = new SqlCommand(sQuery, _sCon))
            {
                cmd.Parameters.AddWithValue("@SampleId", obj.sampleId);
                cmd.Parameters.AddWithValue("@EmployeeId", obj.employeID);
                cmd.Parameters.AddWithValue("@Message", obj.message);
                cmd.Parameters.AddWithValue("@Date", obj.created);
                _sCon.Open();
                cmd.ExecuteScalar();

                if (_sCon.State == System.Data.ConnectionState.Open)
                    _sCon.Close();
                return modified;
            }
        }
        public int UpdateCRFTestResults(DAL.CM obj)
        {
            if (_sCon.State == System.Data.ConnectionState.Open)
                _sCon.Close();
            string sQuery = "Update CRFSampleDetails set TestResults='" + obj.testResult + "' where CRFSampleId='" + obj.CRFSampleId + "'";
            _sCon.Open();
            SqlCommand cmd = new SqlCommand(sQuery, _sCon);
            int modified = cmd.ExecuteNonQuery();
            return modified;
        }
        public int UpdateCRFSampleDetails(DAL.CM obj)
        {
            if (_sCon.State == System.Data.ConnectionState.Open)
                _sCon.Close();
            string sQuery = "Update CRFSampleDetails set unitOfMeasurement='" + obj.unit + "',specification='" + obj.specification + "',testsRequested='" + obj.testsRequested + "' where CRFSampleId='" + obj.CRFSampleId + "'";
            _sCon.Open();
            SqlCommand cmd = new SqlCommand(sQuery, _sCon);
            int modified = cmd.ExecuteNonQuery();
            return modified;
        }
        public int UpdateCRFSampleDetailsMocon(DAL.CM obj)
        {
            if (_sCon.State == System.Data.ConnectionState.Open)
                _sCon.Close();
            string sQuery = "Update CRFSampleDetails set Temp='" + obj.Temp + "',RH='" + obj.RH + "',testsRequested='" + obj.testsRequested + "' where CRFSampleId='" + obj.CRFSampleId + "'";
            _sCon.Open();
            SqlCommand cmd = new SqlCommand(sQuery, _sCon);
            int modified = cmd.ExecuteNonQuery();
            return modified;
        }
        public DataTable getLoginDetails(DAL.CM obj)
        {
            DataTable dt = new DataTable();
            string sQuery = @"select *,ed.DepartmentID as DeptID from users u inner join employees e on u.employeeid = e.id 
                                inner join designation d on d.designationid=e.designationid 
								inner join orgtree o on o.ID = e.id
								inner join employeedepartment ed on ed.employeedepartmentid = e.departmentid
                                where u.username='" + obj.username + "' and u.Password='" + obj.password + "' and deleted=0 and status=1";
            dt = GetDataUsingQuery(sQuery);
            return dt;
        }
        public DataTable getRoleDetails(int employeeID)
        {
            DataTable dt = new DataTable();
            string sQuery = @"Select * from users where employeeid=" + employeeID;
            dt = GetDataUsingQuery(sQuery);
            return dt;
        }
        public DataTable getEmployeeProfile(int EmployeeID)
        {
            DataTable dt = new DataTable();
            string sQuery = @"select e.*,d.employeedepartmentname,s.designationName,e.mobile,e.contactnumber,e.email,u.username,r.rolename from users u 
							        inner join employees e on u.employeeid = e.employeeid 
							        inner join employeedepartment d on d.EmployeeDepartmentID = e.DepartmentID
							        inner join Roles r on r.roleid = u.roleid 
									inner join designation s on e.DesignationID = s.DesignationID where  e.id=" + EmployeeID;
            dt = GetDataUsingQuery(sQuery);
            return dt;
        }
        public DataTable getTestReportID(int SampleID)
        {
            DataTable dt = new DataTable();
            string sQuery = @"select * from Testresultdetails where sampleid=" + SampleID;
            dt = GetDataUsingQuery(sQuery);
            return dt;
        }
        public DataTable GetTestReportDetails1(string SampleId)
        {
            DataTable dt = new DataTable();
            string sQuery = @"Select top 1 c.CloneCRFSampleID,sd.ID,sd.ReceivedDate,sd.SampleId,sd.sampleidseries,sd.Created,d.DepartmentName,
                                    pg.productgroupname,pc.subgroupname,cs.BatchNo,cs.SampleName,cs.SizeOfSample,
                                    ci.inquiryid,cs.sizeofsample,cs.created,cs.TestParameter,cs.TestMethod from sampledetails sd
									inner join CRFCloneList c on sd.Id = c.sampleid
									inner join CustomerInquiry ci on ci.InquiryId = c.EnquiryID
									inner join Department d on ci.DepartmentId = d.DepartmentId                                     
									inner join productsubgroup pc on ci.productcategoryid = pc.SubGroupID
                                    inner join productgroup pg on pg.productgroupid = pc.productgroupid
									inner join CustomerDetails cd on cd.customerid = ci.CustomerId 
									inner join CRFSampleDetails cs on cs.inquiryid = c.enquiryid
									where sd.ID =" + SampleId +
                                @" UNION 
                                    Select  top 1 c.CloneCRFSampleID,sd.ID,sd.ReceivedDate,sd.SampleId,sd.sampleidseries,sd.Created,d.DepartmentName,
                                    pg.productgroupname,pc.subgroupname,cs.BatchNo,cs.SampleName,cs.SizeOfSample,ci.inquiryid,
                                    cs.sizeofsample,cs.created,cs.TestParameter,cs.TestMethod from sampledetails sd
									inner join CRFCloneList c on sd.Id = c.sampleid
									inner join CustomerInquiry ci on ci.InquiryId = c.EnquiryID
									inner join Department d on ci.DepartmentId = d.DepartmentId 
									inner join productsubgroup pc on ci.productcategoryid = pc.SubGroupID
                                    inner join productgroup pg on pg.productgroupid = pc.productgroupid
									inner join CompanyDetails cd on cd.CompanyId = ci.CustomerId 
									inner join CRFSampleDetails cs on cs.inquiryid = c.enquiryid
									where sd.ID =" + SampleId + " order by cs.created desc";
            dt = GetDataUsingQuery(sQuery);
            return dt;
        }
        public DataTable GetTestReportDetails1Mocon(string SampleIdSeriesAll)
        {
            DataTable dt = new DataTable();
            string sQuery = @"Select sd.ReceivedDate,sd.SampleId,sd.sampleidseries,sd.Created,d.DepartmentName,
                                    pg.productgroupname,pc.subgroupname,cs.BatchNo,cs.SampleName,cs.SizeOfSample,
                                    cr.enquiryid as inquiryID,cs.sizeofsample,cs.created,cs.TestParameter,cs.TestMethod from sampledetails sd
									inner join CRFCloneList cr on sd.Id = cr.sampleid
									inner join CustomerInquiry ci on ci.inquiryid = cr.enquiryID
									inner join Department d on ci.DepartmentId = d.DepartmentId                                     
									inner join productsubgroup pc on ci.productcategoryid = pc.SubGroupID
                                    inner join productgroup pg on pg.productgroupid = pc.productgroupid
									inner join CustomerDetails cd on cd.customerid = ci.CustomerId 
									inner join CRFSampleDetails cs on cs.inquiryid = ci.inquiryid 
									where sd.sampleIDSeries in(" + SampleIdSeriesAll + ")  " +
                               @" UNION Select  sd.ReceivedDate,sd.SampleId,sd.sampleidseries,sd.Created,d.DepartmentName,
                                    pg.productgroupname,pc.subgroupname,cs.BatchNo,cs.SampleName,cs.SizeOfSample,cr.enquiryid as inquiryID,
                                    cs.sizeofsample,cs.created,cs.TestParameter,cs.TestMethod from sampledetails sd
									inner join CRFCloneList cr on sd.Id = cr.sampleid
									inner join CustomerInquiry ci on ci.inquiryid = cr.enquiryID
									inner join Department d on ci.DepartmentId = d.DepartmentId 
									inner join productsubgroup pc on ci.productcategoryid = pc.SubGroupID
                                    inner join productgroup pg on pg.productgroupid = pc.productgroupid
									inner join CompanyDetails cd on cd.CompanyId = ci.CustomerId 
									inner join CRFSampleDetails cs on cs.inquiryid = ci.inquiryid
									where sd.sampleIDSeries in(" + SampleIdSeriesAll + ") order by cs.created desc";
            dt = GetDataUsingQuery(sQuery);
            return dt;
        }
        public DataTable GetTestReportDetails2(string SampleId)
        {
            DataTable dt = new DataTable();
            string sQuery = @"select distinct (cd.Title + ' ' + cd.FirstName) as CustomerName, (cp.Title+' '+cp.FirstName) as ContactPerson,
                                    cn.Mobile,cn.Email,ld.AddressLine1,ld.AddressLine2,ld.AddressLine3,ld.city,ld.taluka,
                                    ld.District,ld.pincode,ld.state,ld.country
                                    from CustomerDetails cd
                                    inner join contactpersondetails cp on cp.customermasterid = cd.customermasterid
                                    inner join ContactDetails cn on cn.personid = cp.personid
                                    inner join CRFSampleDetails cs on cs.CustomerId = cd.customerid 
									inner join CRFCloneList c on c.CloneCRFSampleID = cs.CloneCRFSampleID
                                    inner join CustomerInquiry ci on cs.inquiryid = ci.inquiryid
									inner join locationdetails ld on ld.customermasterid = cd.customermasterid
                                    inner join sampledetails sd on sd.id = c.sampleid where sd.ID=" + SampleId +
                                 @" union 
                                    select distinct (cd.CompanyName) as CustomerName, (cp.Title+' '+ cp.FirstName) as ContactPerson,
                                    cn.Mobile,cn.Email,ld.AddressLine1,ld.AddressLine2,ld.AddressLine3,ld.city,ld.taluka,
                                    ld.District,ld.pincode,ld.state,ld.country
                                    from CompanyDetails cd
                                    inner join contactpersondetails cp on cp.customermasterid = cd.customermasterid
                                    inner join ContactDetails cn on cn.personid = cp.personid
                                    inner join CRFSampleDetails cs on cs.CustomerId = cd.CompanyId 
									inner join CRFCloneList c on c.CloneCRFSampleID = cs.CloneCRFSampleID
                                    inner join CustomerInquiry ci on cs.inquiryid = ci.inquiryid
									inner join locationdetails ld on ld.customermasterid = cd.customermasterid
                                    inner join sampledetails sd on sd.id = c.sampleid where sd.ID=" + SampleId;
            dt = GetDataUsingQuery(sQuery);
            return dt;
        }
        public DataTable GetTestReportDetails2Mocon(string SampleIDSeriesAll)
        {
            DataTable dt = new DataTable();
            string sQuery = @"select distinct cd.firstname + cd.lastname as CustomerName,l.AddressLine1,l.AddressLine2,AddressLine3,l.city,l.taluka,l.District,l.Pincode,l.State,l.Country from CustomerDetails cd 
                                    inner join contactpersondetails cp on cd.customermasterid=cp.CustomerMasterId
                                    inner join locationdetails l on l.CustomerMasterId = cp.CustomerMasterId
                                    inner join ContactDetails cn on cn.personid = cp.personid
                                    inner join CustomerInquiry ci on ci.CustomerId = cd.customerID
                                    inner join CRFSampleDetails cs on cs.InquiryId = ci.InquiryId 
                                    inner join CRFCloneList cr on cr.EnquiryID = ci.InquiryId
                                    inner join SampleDetails sd on sd.id = cr.sampleID where sd.sampleidseries in (" + SampleIDSeriesAll + ")" +
                                    @" union select distinct cd.companyname as CustomerName,l.AddressLine1,l.AddressLine2,AddressLine3,l.city,l.taluka,l.District,l.Pincode,l.State,l.Country from CompanyDetails cd 
                                    inner join contactpersondetails cp on cd.customermasterid=cp.CustomerMasterId
                                    inner join locationdetails l on l.CustomerMasterId = cp.CustomerMasterId
                                    inner join ContactDetails cn on cn.personid = cp.personid
                                    inner join CustomerInquiry ci on ci.CustomerId = cd.companyid
                                    inner join CRFSampleDetails cs on cs.InquiryId = ci.InquiryId 
                                    inner join CRFCloneList cr on cr.EnquiryID = ci.InquiryId
                                    inner join SampleDetails sd on sd.id = cr.sampleID where sd.sampleidseries in (" + SampleIDSeriesAll + ")";
            dt = GetDataUsingQuery(sQuery);
            return dt;
        }
        public DataTable GetTestReportDetails3(string SampleId)
        {
            DataTable dt = new DataTable();
            string sQuery = @"select * from testresults t 
                                inner join crfsampledetails c on t.CRFSampleID = c.CRFSampleId 
                                inner join sampledetails s on s.id = t.sampleid
                                and s.ID = " + SampleId;
            dt = GetDataUsingQuery(sQuery);
            return dt;
        }
        public DataTable GetTestReportDetailsPTI(string SampleId)
        {
            DataTable dt = new DataTable();
            string sQuery = @"select distinct cd.CRFSampleID,sd.id,cd.TestParameter,cd.TestMethod,cd.unitofmeasurement,
                                t.specification,td.TestReportNo,td.ULRNo,td.IssueDate,
                                t.TestResult,t.AnalysisStartingDate,t.AnalysisCompletionDate,td.instrumentdetails,
								td.modelPTI,td.CalibrationDueDatePTI,td.ReferenceMaterialDetails,pg.subgroupname 
								from crfsampledetails cd 
								left join testresults t on t.CRFSampleID = cd.CRFSampleId
								left join TestResultDetails td on td.CRFSampleID = cd.CRFSampleID
								inner join CRFCloneList c on c.sampleID = t.sampleid
								inner join CustomerInquiry ci on ci.InquiryId = c.EnquiryID 
								inner join productsubgroup pg on ci.productcategoryid = pg.SubGroupID
                                inner join sampledetails sd on t.sampleid= sd.id and sd.id = " + SampleId;
            dt = GetDataUsingQuery(sQuery);
            return dt;
        }
        public DataTable GetTestReportDetails3Mocon(string SampleIDSeriesAll)
        {
            DataTable dt = new DataTable();
            string sQuery = @"select c.sampleName,s.sampleIDSeries,t1.CRFSampleId,t1.sampleID,t2.sampleID,t1.WVTRTestDate,t1.WVTRTestNo,t1.WVTRResult,t2.OTRTestDate,t2.OTRTestNo,t2.OTRResult from
                                (select sampleID,t.CRFSampleId,WVTRTestDate,WVTRTestNo,WVTRResult from testresults t inner join crfsampledetails c on t.CRFSampleID = c.CRFSampleId where c.DescriptionOfTest = 'WVTR') t1
                                left join
                                (select sampleID,t.CRFSampleId,OTRTestDate,OTRTestNo,OTRResult from testresults t inner join crfsampledetails c on t.CRFSampleID = c.CRFSampleId where c.DescriptionOfTest = 'OTR') t2
                                on t1.sampleID = t2.sampleID 
                                inner join crfsampledetails c on t1.CRFSampleID = c.CRFSampleId
                                inner join sampledetails s on s.id = t1.sampleid where s.sampleIDSeries in(" + SampleIDSeriesAll + ")";
            dt = GetDataUsingQuery(sQuery);
            return dt;
        }
        public int AddTestResultDetailsMechanical(DAL.CM obj)
        {
            int modified = 0;
            if (_sCon.State == System.Data.ConnectionState.Open)
                _sCon.Close();
            string sQuery = @"Insert into TestResultDetails (SampleId,
                                                                TestReportNo,
                                                                ULRNo,
                                                                IssueDate,
                                                                StandardUsedWVTR,
                                                                StandardUsedOTR,
                                                                MethodUsedWVTR,
                                                                MethodUsedOTR,
                                                                RoomTempWVTR,
                                                                RoomTempOTR,
                                                                TestTempWVTR,
                                                                TestTempWOTR,
                                                                TestRHWVTR,
                                                                TestRHOTR,
                                                                CarrierRHWVTR,
                                                                CarrierRHOTR,
                                                                ConditioningWVTR,
                                                                ConditioningOTR,
                                                                TestAreaWVTR,
                                                                TestAreaOTR,
                                                                TestGasSideWVTR,
                                                                TestGasSideOTR,
                                                                O2ConcWVTR,
                                                                O2ConcOTR,
                                                                TestOperatorWVTR,
                                                                TestOperatorOTR,
                                                                Sampling,
                                                                SampleCondition,
                                                                ModelWVTR,
                                                                SrNoWVTR,
                                                                CalibrationCertificateNoWVTR,
                                                                CalibratedByWVTR,
                                                                CalibratedAtWVTR,
                                                                CalibrationCertificateDateWVTR,
                                                                CalibrationDueDateWVTR,
                                                                ModelOTR,
                                                                SrNoOTR,
                                                                CalibrationCertificateNoOTR,
                                                                CalibratedByOTR,
                                                                CalibratedAtOTR,
                                                                CalibrationCertificateDateOTR,
                                                                CalibrationDueDateOTR,
                                                                LabSampleId)output INSERTED.TestResultId values 
                                                                    (@SampleId,
                                                                    @TestReportNo,
                                                                    @ULRNo,
                                                                    @IssueDate,
                                                                    @StandardUsedWVTR,
                                                                    @StandardUsedOTR,
                                                                    @MethodUsedWVTR,
                                                                    @MethodUsedOTR,
                                                                    @RoomTempWVTR,
                                                                    @RoomTempOTR,
                                                                    @TestTempWVTR,
                                                                    @TestTempOTR,
                                                                    @TestRHWVTR,
                                                                    @TestRHOTR,
                                                                    @CarrierRHWVTR,
                                                                    @CarrierRHOTR,
                                                                    @ConditioningWVTR,
                                                                    @ConditioningOTR,
                                                                    @TestAreaWVTR,
                                                                    @TestAreaOTR,
                                                                    @TestGasSideWVTR,
                                                                    @TestGasSideOTR,
                                                                    @O2ConcWVTR,
                                                                    @O2ConcOTR,
                                                                    @TestOperatorWVTR,
                                                                    @TestOperatorOTR,
                                                                    @Sampling,
                                                                    @SampleCondition,
                                                                    @ModelWVTR,
                                                                    @SrNoWVTR,
                                                                    @CalibrationCertificateNoWVTR,
                                                                    @CalibratedByWVTR,
                                                                    @CalibratedAtWVTR,
                                                                    @CalibrationCertificateDateWVTR,
                                                                    @CalibrationDueDateWVTR,
                                                                    @ModelOTR,
                                                                    @SrNoOTR,
                                                                    @CalibrationCertificateNoOTR,
                                                                    @CalibratedByOTR,
                                                                    @CalibratedAtOTR,
                                                                    @CalibrationCertificateDateOTR,
                                                                    @CalibrationDueDateOTR,
                                                                    @LabSampleId)";
            using (SqlCommand cmd = new SqlCommand(sQuery, _sCon))
            {
                cmd.Parameters.AddWithValue("@SampleId", obj.sampleId);
                cmd.Parameters.AddWithValue("@TestReportNo", obj.reportNo);
                cmd.Parameters.AddWithValue("@ULRNo", obj.ulrNo);
                cmd.Parameters.AddWithValue("@IssueDate", obj.issueDate);
                cmd.Parameters.AddWithValue("@StandardUsedWVTR", obj.standardWVTR);
                cmd.Parameters.AddWithValue("@StandardUsedOTR", obj.standardOTR);
                cmd.Parameters.AddWithValue("@MethodUsedWVTR", obj.methodWVTR);
                cmd.Parameters.AddWithValue("@MethodUsedOTR", obj.methodOTR);
                cmd.Parameters.AddWithValue("@RoomTempWVTR", obj.roomTempWVTR);
                cmd.Parameters.AddWithValue("@RoomTempOTR", obj.roomTempOTR);
                cmd.Parameters.AddWithValue("@TestTempWVTR", obj.testTempWVTR);
                cmd.Parameters.AddWithValue("@TestTempOTR", obj.testTempOTR);
                cmd.Parameters.AddWithValue("@TestRHWVTR", obj.testRHWVTR);
                cmd.Parameters.AddWithValue("@TestRHOTR", obj.testRHOTR);
                cmd.Parameters.AddWithValue("@CarrierRHWVTR", obj.carrierRHWVTR);
                cmd.Parameters.AddWithValue("@CarrierRHOTR", obj.carrierRHOTR);
                cmd.Parameters.AddWithValue("@ConditioningWVTR", obj.conditioningWVTR);
                cmd.Parameters.AddWithValue("@ConditioningOTR", obj.conditioningOTR);
                cmd.Parameters.AddWithValue("@TestAreaWVTR", obj.testAreaWVTR);
                cmd.Parameters.AddWithValue("@TestAreaOTR", obj.testAreaOTR);
                cmd.Parameters.AddWithValue("@TestGasSideWVTR", obj.testGasSideWVTR);
                cmd.Parameters.AddWithValue("@TestGasSideOTR", obj.testGasSideOTR);
                cmd.Parameters.AddWithValue("@O2ConcWVTR", obj.o2WVTR);
                cmd.Parameters.AddWithValue("@O2ConcOTR", obj.o2OTR);
                cmd.Parameters.AddWithValue("@TestOperatorWVTR", obj.testOperatorWVTR);
                cmd.Parameters.AddWithValue("@TestOperatorOTR", obj.testOperatorOTR);
                cmd.Parameters.AddWithValue("@ModelWVTR", obj.modelWVTR);
                cmd.Parameters.AddWithValue("@SrNoWVTR", obj.srNoWVTR);
                cmd.Parameters.AddWithValue("@CalibrationCertificateNoWVTR", obj.calCerificateNoWVTR);
                cmd.Parameters.AddWithValue("@CalibratedByWVTR", obj.calByWVTR);
                cmd.Parameters.AddWithValue("@CalibratedAtWVTR", obj.calAtWVTR);
                cmd.Parameters.AddWithValue("@CalibrationCertificateDateWVTR", obj.calCertificateDateWVTR);
                cmd.Parameters.AddWithValue("@CalibrationDueDateWVTR", obj.calDueDateWVTR);
                cmd.Parameters.AddWithValue("@ModelOTR", obj.modelOTR);
                cmd.Parameters.AddWithValue("@SrNoOTR", obj.srNoOTR);
                cmd.Parameters.AddWithValue("@CalibrationCertificateNoOTR", obj.calCerificateNoWVTR);
                cmd.Parameters.AddWithValue("@CalibratedByOTR", obj.calByOTR);
                cmd.Parameters.AddWithValue("@CalibratedAtOTR", obj.calAtOTR);
                cmd.Parameters.AddWithValue("@CalibrationCertificateDateOTR", obj.calCertificateDateOTR);
                cmd.Parameters.AddWithValue("@CalibrationDueDateOTR", obj.calDueDateOTR);
                cmd.Parameters.AddWithValue("@Sampling", obj.sampling);
                cmd.Parameters.AddWithValue("@SampleCondition", obj.samplingCondition);
                cmd.Parameters.AddWithValue("@LabSampleId", obj.labSampleId);
                _sCon.Open();
                modified = (int)cmd.ExecuteScalar();

                if (_sCon.State == System.Data.ConnectionState.Open)
                    _sCon.Close();
                return modified;
            }
        }
        public DataTable GetTestResultDetails(string sampleID)
        {
            DataTable dt = new DataTable();
            string sQuery = @"select distinct td.ULRNo,td.TestReportNo,td.IssueDate,td.AnalysisStartingDate,td.AnalysisCompletionDate,
td.NameOfProduct,td.DateOfMfg,td.DateOfExp,td.TestRequired,td.SampleCondition,td.Sampling,
td.SamplingMethod,td.SampleQuality,t.sampleID from TestResults t inner join TestResultDetails td on t.sampleID = td.SampleId where t.sampleid='" + sampleID + "'";
            dt = GetDataUsingQuery(sQuery);
            return dt;
        }
        public DataTable GetTestResultDetailsChemical(string TestResultId,int dummy)
        {
            DataTable dt = new DataTable();
            string sQuery = @"Select distinct *,sd.sampleID as sampleUID from TestResultDetails td
                        inner join CRFCloneList c on c.sampleid = td.sampleid 
                        inner join sampledetails sd on sd.id = td.sampleid
                        inner join testresults t on t.sampleID = td.SampleId
                        where td.TestResultId in (" + TestResultId + ")";
            dt = GetDataUsingQuery(sQuery);
            return dt;
        }
        public DataTable GetTestResultDetailsPTI(string sampleID)
        {
            DataTable dt = new DataTable();
            string sQuery = @"Select distinct *,sd.sampleID as sampleUID from TestResultDetails td
                        inner join CRFCloneList c on c.sampleid = td.sampleid 
                        inner join sampledetails sd on sd.id = td.sampleid
                        inner join testresults t on t.sampleID = td.SampleId
                        where td.sampleid in (" + sampleID + ")";
            dt = GetDataUsingQuery(sQuery);
            return dt;
        }
        public DataTable GetTestResultDetailsMechanical(string TestResultIdAll)
        {
            DataTable dt = new DataTable();
            string sQuery = @"select cr.CloneCRFSampleID,c.sampleName,s.sampleIDSeries,t1.TestResultId,t1.CRFSampleId,t1.sampleID,t2.sampleID,
                                t1.WVTRTestDate,t1.WVTRTestNo,t1.WVTRResult,t2.OTRTestDate,t2.OTRTestNo,t2.OTRResult,
                                tr.TestResultId,
                                tr.SampleId,
                                TestReportNo,
                                ULRNo,
                                AnalysisStartingDate,
                                AnalysisCompletionDate,
                                TestRequired,
                                SampleCondition,
                                Sampling,
                                InstrumentDetails,
                                TypeOfSample,
                                ReferenceMaterialDetails,
                                StandardUsedWVTR,
                                StandardUsedOTR,
                                MethodUsedWVTR,
                                MethodUsedOTR,
                                RoomTempWVTR,
                                RoomTempOTR,
                                TestTempWVTR,
                                TestTempWOTR,
                                TestRHWVTR,
                                TestRHOTR,
                                CarrierRHWVTR,
                                CarrierRHOTR,
                                ConditioningWVTR,
                                ConditioningOTR,
                                TestAreaWVTR,
                                TestAreaOTR,
                                TestGasSideWVTR,
                                TestGasSideOTR,
                                O2ConcWVTR,
                                O2ConcOTR,
                                TestOperatorWVTR,
                                TestOperatorOTR,
                                SampleDescription,
                                TestDateWVTR,
                                TestDateOTR,
                                TestNoOTR,
                                TestNoWVTR,
                                GDAYWVTR,
                                GDAYOTR,
                                IssueDate,
                                LabSampleId,
                                NameOfProduct,
                                SamplingMethod,
                                SampleQuality,
                                DateOfMfg,
                                DateOfExp,
                                ModelWVTR,
                                SrNoWVTR,
                                CalibrationCertificateNoWVTR,
                                CalibratedByWVTR,
                                CalibratedAtWVTR,
                                CalibrationCertificateDateWVTR,
                                CalibrationDueDateWVTR,
                                ModelOTR,
                                SrNoOTR,
                                CalibrationCertificateNoOTR,
                                CalibratedByOTR,
                                CalibratedAtOTR,
                                CalibrationCertificateDateOTR,
                                CalibrationDueDateOTR,
                                modelPTI,
                                CalibrationDueDatePTI,
                                tr.CRFSampleID,
                                cr.EnquiryID,
                                cr.CustomerCRFSampleID,
                                ID,
                                ReceivedDate,
                                DestroyDate,
                                SampleStatus,
                                sampleIDSeries,
                                SampleVerifiedBy,
                                AnalysisStartingDate,
                                AnalysisCompletionDate,
                                DestroyDate,
                                UnitOfMeasurement,
                                Specification,
                                WVTRTestNo,
                                OTRTestNo,
                                WVTRTestDate,
                                OTRTestDate,s.SampleID as sampleUID
                                from
                                (select sampleID,t.TestResultId,t.CRFSampleId,WVTRTestDate,WVTRTestNo,WVTRResult from testresults t inner join crfsampledetails c on t.CRFSampleID = c.CRFSampleId where c.DescriptionOfTest = 'WVTR') t1
                                left join
                                (select sampleID,t.CRFSampleId,OTRTestDate,OTRTestNo,OTRResult from testresults t inner join crfsampledetails c on t.CRFSampleID = c.CRFSampleId where c.DescriptionOfTest = 'OTR') t2
                                on t1.sampleID = t2.sampleID 
                                inner join TestResultDetails tr on tr.SampleId =t1.sampleID
                                inner join CRFCloneList cr on cr.sampleID = t1.sampleID
                                inner join crfsampledetails c on t1.CRFSampleID = c.CRFSampleId
                                inner join sampledetails s on s.id = t1.sampleid where tr.TestResultId in(" + TestResultIdAll + ")";
            dt = GetDataUsingQuery(sQuery);
            return dt;
        }
        public DataTable GetTestMethod(string prefixText)
        {
            DataTable dt = new DataTable();
            string sQuery = "Select * from TestMethod where testmethod like '%" + prefixText + "%'";
            dt = GetDataUsingQuery(sQuery);
            return dt;
        }
        public DataTable GetTestParameter(string TestMethod)
        {
            DataTable dt = new DataTable();
            string sQuery = "select TestParameter from testmethod where testmethod like '%" + TestMethod + "%'";
            dt = GetDataUsingQuery(sQuery);
            return dt;
        }
        public int AddTestResultDetailsPTI(DAL.CM obj)
        {
            int modified = 0;
            if (_sCon.State == System.Data.ConnectionState.Open)
                _sCon.Close();
            string sQuery = "Insert into TestResultDetails (SampleId,CRFSampleID,TestReportNo,ULRNo,AnalysisStartingDate,AnalysisCompletionDate,CalibrationDueDatePTI,TypeOfSample,ReferenceMaterialDetails,IssueDate)output INSERTED.TestResultId  values (@SampleId,@CRFSampleID,@TestReportNo,@ULRNo,@AnalysisStartingDate,@AnalysisCompletionDate,@CalibrationDueDatePTI,@TypeOfSample,@ReferenceMaterialDetails,@IssueDate)";
            using (SqlCommand cmd = new SqlCommand(sQuery, _sCon))
            {
                cmd.Parameters.AddWithValue("@SampleId", obj.sampleId);
                cmd.Parameters.AddWithValue("@CRFSampleID", obj.CRFSampleId);
                cmd.Parameters.AddWithValue("@TestReportNo", obj.reportNo);
                cmd.Parameters.AddWithValue("@ULRNo", obj.ulrNo);
                cmd.Parameters.AddWithValue("@AnalysisStartingDate", obj.analysisStartingDate);
                cmd.Parameters.AddWithValue("@AnalysisCompletionDate", obj.analysisCompleteDate);
                cmd.Parameters.AddWithValue("@CalibrationDueDatePTI", obj.calDueDatePTI);
                cmd.Parameters.AddWithValue("@TypeOfSample", obj.typeOfSample);
                cmd.Parameters.AddWithValue("@ReferenceMaterialDetails", obj.referenceMaterialDetails);
                cmd.Parameters.AddWithValue("@IssueDate", obj.issueDate);
                _sCon.Open();
                modified = (int)cmd.ExecuteScalar();

                if (_sCon.State == System.Data.ConnectionState.Open)
                    _sCon.Close();
                return modified;
            }
        }
        public int AddTestResultDetailsMicro(DAL.CM obj)
        {
            int modified = 0;
            if (_sCon.State == System.Data.ConnectionState.Open)
                _sCon.Close();
            string sQuery = "Insert into TestResultDetails (SampleId,IssueDate,ULRNo,AnalysisStartingDate,AnalysisCompletionDate,NameOfProduct,DateOfMfg,DateOfExp,SampleQuality,SampleCondition,TestRequired,Sampling,SamplingMethod,TestReportNo)output INSERTED.TestResultId  values (@SampleId,@IssueDate,@ULRNo,@AnalysisStartingDate,@AnalysisCompletionDate,@NameOfProduct,@DateOfMfg,@DateOfExp,@SampleQuality,@SampleCondition,@TestRequired,@Sampling,@SamplingMethod,@TestReportNo)";
            using (SqlCommand cmd = new SqlCommand(sQuery, _sCon))
            {
                cmd.Parameters.AddWithValue("@SampleId", obj.sampleId);
                cmd.Parameters.AddWithValue("@IssueDate", obj.issueDate);
                cmd.Parameters.AddWithValue("@ULRNo", obj.ulrNo);
                cmd.Parameters.AddWithValue("@AnalysisStartingDate", obj.analysisStartingDate);
                cmd.Parameters.AddWithValue("@AnalysisCompletionDate", obj.analysisCompleteDate);
                cmd.Parameters.AddWithValue("@NameOfProduct", obj.nameOfProduct);
                cmd.Parameters.AddWithValue("@DateOfMfg", obj.dateOfMfg);
                cmd.Parameters.AddWithValue("@DateOfExp", obj.dateOfExp);
                cmd.Parameters.AddWithValue("@SampleQuality", obj.sampleQuality);
                cmd.Parameters.AddWithValue("@SampleCondition", obj.sampleCondition);
                cmd.Parameters.AddWithValue("@TestRequired", obj.testRequired);
                cmd.Parameters.AddWithValue("@Sampling", obj.sampling);
                cmd.Parameters.AddWithValue("@SamplingMethod", obj.samplingMethod);
                cmd.Parameters.AddWithValue("@TestReportNo", obj.reportNo);
                _sCon.Open();
                modified = (int)cmd.ExecuteScalar();

                if (_sCon.State == System.Data.ConnectionState.Open)
                    _sCon.Close();
                return modified;
            }
        }

        public int AddTestResultDetailsChemical(DAL.CM obj)
        {
            int modified = 0;
            if (_sCon.State == System.Data.ConnectionState.Open)
                _sCon.Close();
            string sQuery = "Insert into TestResultDetails (SampleId,IssueDate,ULRNo,AnalysisStartingDate,AnalysisCompletionDate,NameOfProduct,DateOfMfg,DateOfExp,SampleQuality,SampleCondition,TestRequired,TestReportNo)output INSERTED.TestResultId  values (@SampleId,@IssueDate,@ULRNo,@AnalysisStartingDate,@AnalysisCompletionDate,@NameOfProduct,@DateOfMfg,@DateOfExp,@SampleQuality,@SampleCondition,@TestRequired,@TestReportNo)";
            using (SqlCommand cmd = new SqlCommand(sQuery, _sCon))
            {
                cmd.Parameters.AddWithValue("@SampleId", obj.sampleId);
                cmd.Parameters.AddWithValue("@IssueDate", obj.issueDate);
                cmd.Parameters.AddWithValue("@ULRNo", obj.ulrNo);
                cmd.Parameters.AddWithValue("@AnalysisStartingDate", obj.analysisStartingDate);
                cmd.Parameters.AddWithValue("@AnalysisCompletionDate", obj.analysisCompleteDate);
                cmd.Parameters.AddWithValue("@NameOfProduct", obj.nameOfProduct);
                cmd.Parameters.AddWithValue("@DateOfMfg", obj.dateOfMfg);
                cmd.Parameters.AddWithValue("@DateOfExp", obj.dateOfExp);
                cmd.Parameters.AddWithValue("@SampleQuality", obj.sampleQuality);
                cmd.Parameters.AddWithValue("@SampleCondition", obj.sampleCondition);
                cmd.Parameters.AddWithValue("@TestRequired", obj.testRequired);
                cmd.Parameters.AddWithValue("@TestReportNo", obj.reportNo);
                _sCon.Open();
                modified = (int)cmd.ExecuteScalar();

                if (_sCon.State == System.Data.ConnectionState.Open)
                    _sCon.Close();
                return modified;
            }
        }

        public DataTable GetTestReportResult(string SampleId)
        {
            DataTable dt = new DataTable();
            string sQuery = @"select ROW_NUMBER() OVER(ORDER BY c.crfsampleid ASC) AS Sr,* from crfsampledetails c 
                                inner join TestResults t on c.crfsampleid = t.crfsampleid and t.sampleID='" + SampleId + "'";
            dt = GetDataUsingQuery(sQuery);
            return dt;
        }
        public DataTable GetTestReportResultPTI(string SampleId)
        {
            DataTable dt = new DataTable();
            string sQuery = @"select distinct c.inquiryID,cl.cloneCRFSampleID,td.ULRNo,td.TestReportNo,td.IssueDate,sd.ReceivedDate,sd.sampleid as sampleUID,pg.SubGroupName,
								c.testparameter,c.testmethod,c.unitofmeasurement,
								td.AnalysisStartingDate,td.AnalysisCompletionDate,
							    c.SizeOfSample,td.InstrumentDetails,td.CalibrationDueDatePTI,c.samplename,td.ReferenceMaterialDetails,
								c.crfsampleid,t.TestResult,sd.sampleidseries,td.testresultID
								from crfsampledetails c 
								inner join TestResults t on c.crfsampleid = t.crfsampleid 
								inner join CRFCloneList cl on cl.sampleid = t.sampleid 
								inner join customerinquiry ci on ci.inquiryid=cl.enquiryid
								inner join productsubgroup pg on ci.productcategoryid = pg.SubGroupID                                
								inner join sampledetails sd on sd.id = t.sampleID 
							    inner join TestResultDetails td on t.CRFSampleID =td.CRFSampleID and t.sampleID='" + SampleId + "'";
            dt = GetDataUsingQuery(sQuery);
            return dt;
        }
        public DataTable GetTestResult(string SampleId)
        {
            DataTable dt = new DataTable();
            string sQuery = @"Select * from TestResults where sampleID='" + SampleId + "'";
            dt = GetDataUsingQuery(sQuery);
            return dt;
        }
        public int AddCustomerFeedback(DAL.CM obj)
        {
            int modified = 0;
            if (_sCon.State == System.Data.ConnectionState.Open)
                _sCon.Close();
            string sQuery = "Insert into CustomerFeedback (InquiryId,FeedbackName,FeedbackValue,CustomerRemark,FeedbackDate,FeedbackWeightage)output INSERTED.FeedbackId  values (@InquiryId,@FeedbackName,@FeedbackValue,@CustomerRemark,@FeedbackDate,@FeedbackWeightage)";
            using (SqlCommand cmd = new SqlCommand(sQuery, _sCon))
            {
                cmd.Parameters.AddWithValue("@InquiryId", obj.inquiryId);
                cmd.Parameters.AddWithValue("@FeedbackName", obj.feedbackName);
                cmd.Parameters.AddWithValue("@FeedbackValue", obj.feedbackValue);
                cmd.Parameters.AddWithValue("@CustomerRemark", obj.customerRemark);
                cmd.Parameters.AddWithValue("@FeedbackDate", obj.feedbackDate);
                cmd.Parameters.AddWithValue("@FeedbackWeightage", obj.feedbackWeightage);
                _sCon.Open();
                modified = (int)cmd.ExecuteScalar();

                if (_sCon.State == System.Data.ConnectionState.Open)
                    _sCon.Close();
                return modified;
            }
        }
        public DataTable GetFeedbackWeightage(string FeedbackValue)
        {
            DataTable dt = new DataTable();
            string sQuery = "Select * from FeedbackWeightage where FeedbackValue='" + FeedbackValue + "'";
            dt = GetDataUsingQuery(sQuery);
            return dt;
        }
        public DataTable GetCustomerForFeedback(string CloneCRFSampleID)
        {
            DataTable dt = new DataTable();
            string sQuery = @"Select c.*,(cd.Title+' '+cd.FirstName) as CustomerName from CRFCloneList c
								inner join CustomerInquiry ci on ci.InquiryId = c.EnquiryID  
                                inner join CustomerDetails cd on ci.CustomerId=cd.CustomerId 
                                where c.CloneCRFSampleID=" + CloneCRFSampleID +
                             @" union Select c.*,(cd.CompanyName) as CustomerName from CRFCloneList c
							    inner join CustomerInquiry ci on ci.InquiryId = c.EnquiryID  
                                inner join CompanyDetails cd on ci.CustomerId=cd.CompanyId where c.CloneCRFSampleID=" + CloneCRFSampleID;
            dt = GetDataUsingQuery(sQuery);
            return dt;
        }
        public DataTable getCustomerFeedback(int inquiryID)
        {
            DataTable dt = new DataTable();
            string sQuery = "Select * from customerFeedback where inquiryID='" + inquiryID + "'";
            dt = GetDataUsingQuery(sQuery);
            return dt;
        }
        public DataTable getCustomerFeedbackList()
        {
            DataTable dt = new DataTable();
            string sQuery = @"SELECT distinct cf.inquiryid,cd.firstname + ' ' + cd.lastname as customername,Average
                                  FROM customerFeedback AS cf 
                                  inner join customerinquiry ci on cf.inquiryid = ci.inquiryid
                                  inner join CustomerDetails cd on cd.customerid = ci.customerid
                                  JOIN (SELECT inquiryid, SUM(FeedbackWeightage) AS Average
                                          FROM customerFeedback
                                         GROUP BY inquiryid
                                       ) AS s ON cf.inquiryid = s.inquiryid
                                union
                                SELECT distinct cf.inquiryid,cd.companyname as customername,Average
                                  FROM customerFeedback AS cf 
                                  inner join customerinquiry ci on cf.inquiryid = ci.inquiryid
                                  inner join companydetails cd on cd.companyid = ci.customerid
                                  JOIN (SELECT inquiryid, SUM(FeedbackWeightage) AS Average
                                          FROM customerFeedback
                                         GROUP BY inquiryid
                                       ) AS s ON cf.inquiryid = s.inquiryid";
            dt = GetDataUsingQuery(sQuery);
            return dt;
        }
        public DataTable getCustomerFeedbackAverage(int inquiryID)
        {
            DataTable dt = new DataTable();
            string sQuery = @"Select (AVG(Cast(feedbackweightage as Float))/10)*100 as average 
                                from customerFeedback where inquiryID='" + inquiryID + "'";
            dt = GetDataUsingQuery(sQuery);
            return dt;
        }
        public DataTable GetUserDetails()
        {
            DataTable dt = new DataTable();
            string sQuery = @"select * from users u 
                                inner join  employees e on e.employeeid = u.employeeid
                                inner join designation d on d.designationid = e.designationid
                                inner join Roles r on r.roleid = u.roleid";
            dt = GetDataUsingQuery(sQuery);
            return dt;
        }
        public DataTable GetAllDesignations()
        {
            DataTable dt = new DataTable();
            string sQuery = @"select * from designation";
            dt = GetDataUsingQuery(sQuery);
            return dt;
        }
        public DataTable GetAllDepartments()
        {
            DataTable dt = new DataTable();
            string sQuery = @"select * from department";
            dt = GetDataUsingQuery(sQuery);
            return dt;
        }
        public DataTable GetSupervisors()
        {
            DataTable dt = new DataTable();
            string sQuery = @"select e.employeename,count(*) as allocated,EmployeeDepartmentName as Departmentname from orgtree o 
                                inner join employees e on o.id = e.EmployeeID
                                inner join EmployeeDepartment d on e.DepartmentID = d.EmployeeDepartmentID 
                                inner join allocation a on a.employeeid = e.employeeid group by e.id,e.employeename,
                                o.name, EmployeeDepartmentName order by EmployeeDepartmentName asc";
            dt = GetDataUsingQuery(sQuery);
            return dt;
        }
        public DataTable GetEmployees()
        {
            DataTable dt = new DataTable();
            string sQuery = @"select * from employees e 
                                inner join Department d on e.departmentid = d.departmentid
                                inner join Designation ds on ds.designationid = e.DesignationID
                                inner join users u on u.employeeid = e.employeeid
								inner join roles r on u.roleid = r.roleid";
            dt = GetDataUsingQuery(sQuery);
            return dt;
        }
        public int AddEmployee(DAL.CM obj)
        {
            if (_sCon.State == System.Data.ConnectionState.Open)
                _sCon.Close();
            string sQuery = @"insert into Employees(EmployeeID,EmployeeName,DepartmentID,created,DesignationID,ContactNumber,Email,
                              Mobile)output INSERTED.ID values(@EmployeeID,@EmployeeName,@DepartmentID,@created,
                              @DesignationID,@ContactNumber,@Email,@Mobile)";
            using (SqlCommand cmd = new SqlCommand(sQuery, _sCon))
            {
                cmd.Parameters.AddWithValue("@EmployeeID", obj.EmployeeID);
                cmd.Parameters.AddWithValue("@EmployeeName", obj.EmployeeName);
                cmd.Parameters.AddWithValue("@DepartmentID", obj.employeeDepartmentID);
                cmd.Parameters.AddWithValue("@created", DateTime.Now);
                cmd.Parameters.AddWithValue("@DesignationID", obj.designationID);
                cmd.Parameters.AddWithValue("@ContactNumber", obj.phone);
                cmd.Parameters.AddWithValue("@Email", obj.email);
                cmd.Parameters.AddWithValue("@Mobile", obj.mobile);
                _sCon.Open();
                int modified = (int)cmd.ExecuteScalar();

                if (_sCon.State == System.Data.ConnectionState.Open)
                    _sCon.Close();
                return modified;
            }
        }
        public int AddUser(DAL.CM obj)
        {
            if (_sCon.State == System.Data.ConnectionState.Open)
                _sCon.Close();
            string sQuery = @"insert into users(UserName,Password,AddedDate,status,deleted,employeeID,RoleID)
                              output INSERTED.UserID values(@UserName,@Password,@AddedDate,@status,@deleted,@employeeID,
                              @RoleID)";
            using (SqlCommand cmd = new SqlCommand(sQuery, _sCon))
            {
                cmd.Parameters.AddWithValue("@UserName", obj.username);
                cmd.Parameters.AddWithValue("@Password", obj.password);
                cmd.Parameters.AddWithValue("@AddedDate", DateTime.Now);
                cmd.Parameters.AddWithValue("@status", obj.userStatus);
                cmd.Parameters.AddWithValue("@deleted", 0);
                cmd.Parameters.AddWithValue("@employeeID", obj.empID);
                cmd.Parameters.AddWithValue("@RoleID", obj._roleID);
                _sCon.Open();
                int modified = (int)cmd.ExecuteScalar();

                if (_sCon.State == System.Data.ConnectionState.Open)
                    _sCon.Close();
                return modified;
            }
        }
        public DataTable[] GetSampleCount()
        {
            string sQuery = "";
            DataTable dtToday = new DataTable();
            DataTable dtWeek = new DataTable();
            DataTable dtMonth = new DataTable();
            DateTime TodayDate = DateTime.Today;
            DateTime prevWeek = DateTime.Now.AddDays(-7);
            DateTime prevMonth = DateTime.Now.AddDays(-30);
            sQuery = "Select * from SampleDetails where Created ='" + TodayDate + "'";
            dtToday = GetDataUsingQuery(sQuery);
            sQuery = "Select * from SampleDetails where Created <='" + TodayDate + "' and Created >='" + prevWeek + "'";
            dtWeek = GetDataUsingQuery(sQuery);
            sQuery = "Select * from SampleDetails where Created <='" + TodayDate + "' and Created >='" + prevMonth + "'";
            dtMonth = GetDataUsingQuery(sQuery);
            return new DataTable[] { dtToday, dtWeek, dtMonth };
        }
        public DataTable[] GetStatus(string type)
        {
            string sQuery = "";
            DataTable dtInquiry = new DataTable();
            DataTable dtNewCustomer = new DataTable();
            DataTable dtAssigned = new DataTable();
            DataTable dtCompleted = new DataTable();
            if (type == "today")
            {
                DateTime TodayDate = DateTime.Today;
                string today = TodayDate.ToString("d");
                sQuery = "Select * from CustomerInquiry where Created='" + today + "' ";
                dtInquiry = GetDataUsingQuery(sQuery);
                sQuery = "Select * from CustomerInquiry ci inner join CustomerDetails cd on ci.CustomerId = cd.customerId where ci.InquiryStatusId = '1' and Created='" + TodayDate + "'";
                dtNewCustomer = GetDataUsingQuery(sQuery);
                sQuery = "Select * from CustomerInquiry ci inner join CustomerDetails cd on ci.CustomerId = cd.customerId where ci.InquiryStatusId = '19' and Created='" + TodayDate + "'";
                dtAssigned = GetDataUsingQuery(sQuery);
                sQuery = "Select * from CustomerInquiry ci inner join CustomerDetails cd on ci.CustomerId = cd.customerId where ci.InquiryStatusId = '20' and Created='" + TodayDate + "'";
                dtCompleted = GetDataUsingQuery(sQuery);
            }
            if (type == "week")
            {
                DateTime TodaydateOnly = DateTime.Today;
                string today = TodaydateOnly.ToString("d");
                DateTime prevWeek = DateTime.Now.AddDays(-7);
                sQuery = "Select * from CustomerInquiry where Created <='" + today + "' and Created >='" + prevWeek + "'";
                dtInquiry = GetDataUsingQuery(sQuery);
                sQuery = "Select * from CustomerInquiry ci inner join CustomerDetails cd on ci.CustomerId = cd.customerId where ci.InquiryStatusId = '1' and Created <='" + today + "' and Created >='" + prevWeek + "'";
                dtNewCustomer = GetDataUsingQuery(sQuery);
                sQuery = "Select * from CustomerInquiry ci inner join CustomerDetails cd on ci.CustomerId = cd.customerId where ci.InquiryStatusId = '19' and Created <='" + today + "' and Created >='" + prevWeek + "'";
                dtAssigned = GetDataUsingQuery(sQuery);
                sQuery = "Select * from CustomerInquiry ci inner join CustomerDetails cd on ci.CustomerId = cd.customerId where ci.InquiryStatusId = '20' and Created <='" + today + "' and Created >='" + prevWeek + "'";
                dtCompleted = GetDataUsingQuery(sQuery);
            }
            if (type == "month")
            {
                DateTime TodaydateOnly = DateTime.Today;
                string today = TodaydateOnly.ToString("d");
                DateTime prevMonth = DateTime.Now.AddDays(-30);
                sQuery = "Select * from CustomerInquiry where Created <='" + today + "' and Created >='" + prevMonth + "'";
                dtInquiry = GetDataUsingQuery(sQuery);
                sQuery = "Select * from CustomerInquiry ci inner join CustomerDetails cd on ci.CustomerId = cd.customerId where ci.InquiryStatusId = '1' and Created <='" + today + "' and Created >='" + prevMonth + "'";
                dtNewCustomer = GetDataUsingQuery(sQuery);
                sQuery = "Select * from CustomerInquiry ci inner join CustomerDetails cd on ci.CustomerId = cd.customerId where ci.InquiryStatusId = '19' and Created <='" + today + "' and Created >='" + prevMonth + "'";
                dtAssigned = GetDataUsingQuery(sQuery);
                sQuery = "Select * from CustomerInquiry ci inner join CustomerDetails cd on ci.CustomerId = cd.customerId where ci.InquiryStatusId = '20' and Created <='" + today + "' and Created >='" + prevMonth + "'";
                dtCompleted = GetDataUsingQuery(sQuery);
            }
            return new DataTable[] { dtInquiry, dtNewCustomer, dtAssigned, dtCompleted };
        }
        public DataTable getSampleDepartment(int sampleID)
        {
            DataTable dt = new DataTable();
            string sQuery = @"select * from sampledetails s 
                                inner join crfclonelist c on s.id = c.sampleid
                                inner join CustomerInquiry ci on ci.InquiryId = c.EnquiryID where s.ID =" + sampleID;
            dt = GetDataUsingQuery(sQuery);
            return dt;
        }
        public DataTable getSampleInquiryID(string sampleIDSeries)
        {
            DataTable dt = new DataTable();
            string sQuery = @"select *,c.enquiryid as inquiryID from SampleDetails sd 
                                inner join CRFCloneList c on c.sampleID = sd.id 
                                where sd.sampleIDSeries='" + sampleIDSeries + "'";
            dt = GetDataUsingQuery(sQuery);
            return dt;
        }
        public DataTable getSampleDetailsForReport(int sampleID)
        {
            DataTable dt = new DataTable();
            string sQuery = @"select c.inquiryid,c.created,i.statusname,c.CustomerId,c.InquiryDetail,cd.CustomerMasterId,cd.FirstName as customername from InquiryStatus i 
                                    inner join CustomerInquiry c on i.InquiryStatusId = c.InquiryStatusId
                                    inner join CustomerDetails cd on c.CustomerId = cd.CustomerId where c.sampleID=" + sampleID +
                                 @" union
                                    select c.inquiryid,c.created,i.statusname,c.CustomerId,c.InquiryDetail,cd.CustomerMasterId,cd.companyname as customername from InquiryStatus i 
                                    inner join CustomerInquiry c on i.InquiryStatusId = c.InquiryStatusId
                                    inner join companydetails cd on cd.companyid = c.CustomerId  where c.sampleID= " + sampleID + " order by c.Created desc";
            dt = GetDataUsingQuery(sQuery);
            return dt;
        }
        public DataTable getTestDetailsForEnquiryStatus(int sampleID)
        {
            DataTable dt = new DataTable();
            string sQuery = @"select td.*,cs.InquiryId from TestResultDetails td inner join CRFSampleDetails cs on td.CRFSampleID = cs.CRFSampleId where td.sampleid=" + sampleID + " order by TestResultID desc";
            dt = GetDataUsingQuery(sQuery);
            return dt;
        }
        public DataTable getLastTestReportNo()
        {
            DataTable dt = new DataTable();
            string sQuery = "Select top 1 testreportno from TestResultDetails order by TestResultId desc";
            dt = GetDataUsingQuery(sQuery);
            return dt;
        }
        public DataTable getLastSampleID()
        {
            DataTable dt = new DataTable();
            string sQuery = "Select top 1 sampleIDSeries from sampledetails order by id desc";
            dt = GetDataUsingQuery(sQuery);
            return dt;
        }
        public DataTable getSampleIDSeries(int sampleID)
        {
            DataTable dt = new DataTable();
            string sQuery = "Select sampleIDSeries from sampledetails where id=" + sampleID;
            dt = GetDataUsingQuery(sQuery);
            return dt;
        }
        public DataTable GetScriptCodes()
        {
            DataTable dt = new DataTable();
            string sQuery = "Select * from ScriptLookUp";
            dt = GetDataUsingQuery(sQuery);
            return dt;
        }
        public DataTable GetScriptSample()
        {
            DataTable dt = new DataTable();
            string sQuery = "Select * from ScriptSample";
            dt = GetDataUsingQuery(sQuery);
            return dt;
        }
        public int AddScriptCode(DAL.CM obj)
        {
            int modified = 0;
            if (_sCon.State == System.Data.ConnectionState.Open)
                _sCon.Close();
            string sQuery = "insert into ScriptSample (ScriptSample) values(@ScriptSample)";
            using (SqlCommand cmd = new SqlCommand(sQuery, _sCon))
            {
                cmd.Parameters.AddWithValue("@ScriptSample", obj.ScriptSample);
                _sCon.Open();
                cmd.ExecuteScalar();

                if (_sCon.State == System.Data.ConnectionState.Open)
                    _sCon.Close();
                return modified;
            }
        }
        public DataTable checkTestResultExists(int CRFSampleID)
        {
            DataTable dt = new DataTable();
            string sQuery = "Select * from TestResults where CRFSampleID=" + CRFSampleID;
            dt = GetDataUsingQuery(sQuery);
            return dt;
        }
        public DataTable checkTestResultDetailsExist(int CRFSampleID)
        {
            DataTable dt = new DataTable();
            string sQuery = "Select * from TestResultDetails where CRFSampleID=" + CRFSampleID;
            dt = GetDataUsingQuery(sQuery);
            return dt;
        }
        public int UpdateTestResults(DAL.CM obj)
        {
            if (_sCon.State == System.Data.ConnectionState.Open)
                _sCon.Close();
            string sQuery = @"Update TestResults set TestResult='" + obj.testResult + "', UnitOfMeasurement = '" + obj.unit + "', Specification = '" + obj.specification + "',AnalysisStartingDate = '" + obj.analysisStartingDate + "',AnalysisCompletionDate = '" + obj.analysisCompleteDate + "',DestroyDate = '" + obj.destroyDate + "' where CRFSampleID =" + obj.CRFSampleId;
            _sCon.Open();
            SqlCommand cmd = new SqlCommand(sQuery, _sCon);
            int modified = cmd.ExecuteNonQuery();
            return modified;
        }
        public int UpdateTestResultDetails(DAL.CM obj)
        {
            if (_sCon.State == System.Data.ConnectionState.Open)
                _sCon.Close();
            string sQuery = @"Update TestResultDetails set InstrumentDetails='" + obj.InstrumentDetails + "', CalibrationDueDatePTI = '" + obj.calDueDatePTI + "',ReferenceMaterialDetails = '" + obj.referenceMaterialDetails + "' where CRFSampleID =" + obj.CRFSampleId;
            _sCon.Open();
            SqlCommand cmd = new SqlCommand(sQuery, _sCon);
            int modified = cmd.ExecuteNonQuery();
            return modified;
        }
        public int UpdateTestResultsMocon(DAL.CM obj)
        {
            if (_sCon.State == System.Data.ConnectionState.Open)
                _sCon.Close();
            string sQuery = @"Update TestResults set sampleId='" + obj.sampleId + "',WVTRTestDate ='" + obj.WVTRTestDate + "',WVTRTestNo ='" + obj.WVTRTestNo + "', WVTRResult = '" + obj.WVTRResult + "',OTRTestDate='" + obj.OTRTestDate + "',OTRTestNo='" + obj.OTRTestNo + "', OTRResult = '" + obj.OTRResult + "', AnalysisStartingDate = '" + obj.analysisStartingDate + "',AnalysisCompletionDate = '" + obj.analysisCompleteDate + "',DestroyDate = '" + obj.destroyDate + "' where CRFSampleID =" + obj.CRFSampleId;
            _sCon.Open();
            SqlCommand cmd = new SqlCommand(sQuery, _sCon);
            int modified = cmd.ExecuteNonQuery();
            return modified;
        }
        public int AddTestResults(DAL.CM obj)
        {
            int modified = 0;
            if (_sCon.State == System.Data.ConnectionState.Open)
                _sCon.Close();
            string sQuery = "Insert into TestResults (CRFSampleID,sampleID,TestResult,UnitOfMeasurement,Specification,AnalysisStartingDate,AnalysisCompletionDate,DestroyDate)output INSERTED.TestResultId values (@CRFSampleID,@sampleID,@TestResult,@UnitOfMeasurement,@Specification,@AnalysisStartingDate,@AnalysisCompletionDate,@DestroyDate)";
            using (SqlCommand cmd = new SqlCommand(sQuery, _sCon))
            {
                cmd.Parameters.AddWithValue("@CRFSampleID", obj.CRFSampleId);
                cmd.Parameters.AddWithValue("@sampleID", obj.sampleId);
                cmd.Parameters.AddWithValue("@TestResult", obj.testResult);
                cmd.Parameters.AddWithValue("@UnitOfMeasurement", obj.unit);
                cmd.Parameters.AddWithValue("@Specification", obj.specification);
                cmd.Parameters.AddWithValue("@AnalysisStartingDate", obj.analysisStartingDate);
                cmd.Parameters.AddWithValue("@AnalysisCompletionDate", obj._analysisCompletionDate);
                cmd.Parameters.AddWithValue("@DestroyDate", obj.destroyDate);
                _sCon.Open();
                modified = (int)cmd.ExecuteScalar();

                if (_sCon.State == System.Data.ConnectionState.Open)
                    _sCon.Close();
                return modified;
            }

        }
        public int AddTestResultsMocon(DAL.CM obj)
        {
            int modified = 0;
            if (_sCon.State == System.Data.ConnectionState.Open)
                _sCon.Close();
            string sQuery = "Insert into TestResults (CRFSampleID,sampleID,WVTRResult,OTRResult,WVTRTestDate,OTRTestDate,WVTRTestNo,OTRTestNo,AnalysisStartingDate,AnalysisCompletionDate,DestroyDate)output INSERTED.TestResultId values (@CRFSampleID,@SampleID,@WVTRResult,@OTRResult,@WVTRTestDate,@OTRTestDate,@WVTRTestNo,@OTRTestNo,@AnalysisStartingDate,@AnalysisCompletionDate,@DestroyDate)";
            using (SqlCommand cmd = new SqlCommand(sQuery, _sCon))
            {
                cmd.Parameters.AddWithValue("@CRFSampleID", obj.CRFSampleId);
                cmd.Parameters.AddWithValue("@SampleID", obj.sampleId);
                cmd.Parameters.AddWithValue("@WVTRResult", obj.WVTRResult);
                cmd.Parameters.AddWithValue("@OTRResult", obj.OTRResult);
                cmd.Parameters.AddWithValue("@WVTRTestDate", obj.WVTRTestDate);
                cmd.Parameters.AddWithValue("@OTRTestDate", obj.OTRTestDate);
                cmd.Parameters.AddWithValue("@WVTRTestNo", obj.WVTRTestNo);
                cmd.Parameters.AddWithValue("@OTRTestNo", obj.OTRTestNo);
                cmd.Parameters.AddWithValue("@AnalysisStartingDate", obj.analysisStartingDate);
                cmd.Parameters.AddWithValue("@AnalysisCompletionDate", obj._analysisCompletionDate);
                cmd.Parameters.AddWithValue("@DestroyDate", obj.destroyDate);
                _sCon.Open();
                modified = (int)cmd.ExecuteScalar();

                if (_sCon.State == System.Data.ConnectionState.Open)
                    _sCon.Close();
                return modified;
            }
        }
        public void DeleteScriptSample(int ID)
        {
            try
            {
                if (_sCon.State != ConnectionState.Open)
                {
                    _sCon.Open();
                }
                SqlCommand cmd = new SqlCommand(sQuery, _sCon);
                {
                    cmd.CommandText = "DELETE FROM ScriptSample WHERE ID = @ID";
                    cmd.Parameters.AddWithValue("@ID", ID);
                    cmd.ExecuteNonQuery();
                }
            }
            catch
            {

            }
        }
        public DataTable getSignatory(int EmployeeID)
        {
            DataTable dt = new DataTable();
            string sQuery = @"select * from employees e inner join designation d on e.designationid=d.designationid  
                                where e.employeeid=" + EmployeeID;
            dt = GetDataUsingQuery(sQuery);
            return dt;
        }
        public DataTable getChartData()
        {
            DataTable dt = new DataTable();
            string sQuery = @"select * from SendData";
            dt = GetDataUsingQuery(sQuery);
            return dt;
        }
        public int AddCRFClone(DAL.CM obj)
        {
            if (_sCon.State == System.Data.ConnectionState.Open)
                _sCon.Close();
            string sQuery = "insert into CRFCloneList(EnquiryID,CustomerCRFSampleID)output INSERTED.CloneCRFSampleID values(@EnquiryID,@CustomerCRFSampleID)";
            using (SqlCommand cmd = new SqlCommand(sQuery, _sCon))
            {
                cmd.Parameters.AddWithValue("@EnquiryID", obj.inquiryId);
                cmd.Parameters.AddWithValue("@CustomerCRFSampleID", obj.CustomerCRFSampleID);
                _sCon.Open();
                int modified = (int)cmd.ExecuteScalar();

                if (_sCon.State == System.Data.ConnectionState.Open)
                    _sCon.Close();
                return modified;
            }
        }
        public void ErrorHandler(int errCode, string msg)
        {
            switch (errCode)
            {
                case 1:
                    HttpContext.Current.Session["ErrorMessage"] = msg;
                    HttpContext.Current.Response.Redirect("Error.aspx");
                    break;
                default:
                    break;
            }
        }
        public DataTable GetDataUsingQuery(string sQuery)
        {
            DataTable dt = new DataTable();
            try
            {
                if (_sCon.State != ConnectionState.Open)
                {
                    _sCon.Open();
                }
                SqlCommand cmd = new SqlCommand(sQuery, _sCon);
                SqlDataAdapter adp = new SqlDataAdapter(cmd);
                adp.Fill(dt);

            }
            catch
            {

            }
            return dt;
        }

    }

}