﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Net;
using System.Net.Mail;
using System.Text.RegularExpressions;
using System.Web;

namespace LIMS.DAL
{
    public class mailer
    {
        public void SendMail(string fromAddress, string toAddress, string ccAddress, string bccAddress, string attach, string subject, string body)
        {
            using (MailMessage mail = BuildMessageWith(fromAddress, toAddress.Replace(',', ';'), ccAddress.Replace(',', ';'), bccAddress.Replace(',', ';'), attach.Replace(',', ';'), subject, body))
            {
                SendMail(mail);
            }
        }

        public static void SendMail(MailMessage mail)
        {
            try
            {
                
                MailMessage mailMessage = new MailMessage();
                mailMessage.From = new MailAddress("support@rni-solutions.com", "Admin");
                mailMessage.Bcc.Add("jinitha.s@rniinternational.com");
                mailMessage.Subject = "Customer Request Form";
                mailMessage.Body = "Customer Request Form Body";
                mail.From = new MailAddress("support@rni-solutions.com", "Admin");
                mailMessage.IsBodyHtml = true;
                SmtpClient smtpClient = new SmtpClient("localhost", 25);
                smtpClient.Send(mail);
            }
            catch (Exception e)
            {

                throw e;

            }
        }

        public void SendMail(string fromAddress, string toAddress, string subject, string body)
        {
            using (MailMessage mail = BuildMessageWith(fromAddress, toAddress.Replace(',', ';'), subject, body))
            {
                try
                {
                    MailMessage message = new MailMessage();
                    SmtpClient smtpClient = new SmtpClient();
                    string msg = string.Empty;
                    MailAddress from = new MailAddress("support@rni-solutions.com");
                    message.From = from;
                    message.To.Add(toAddress);
                    message.Subject = subject;
                    message.IsBodyHtml = true;
                    message.Body = body;
                    smtpClient.Host = "relay-hosting.secureserver.net";   //-- Donot change.
                    smtpClient.Port = 25; //--- Donot change
                    smtpClient.EnableSsl = false;//--- Donot change
                    smtpClient.UseDefaultCredentials = true;
                    smtpClient.Credentials = new System.Net.NetworkCredential("support@rni-solutions.com", "jinitha123");
                    smtpClient.Send(message);

                }
                catch (Exception e)
                {

                    throw e;

                }
            }
        }

        public void SendMail(string fromAddress, string toAddress, string subject, string body, string attach)
        {
            using (MailMessage mail = BuildMessageWith(fromAddress, toAddress.Replace(',', ';'), subject, body, attach))
            {
                try
                {

                    MailMessage message = new MailMessage();
                    SmtpClient smtpClient = new SmtpClient();
                    string msg = string.Empty;
                    MailAddress from = new MailAddress("support@rni-solutions.com");
                    message.From = from;
                    message.To.Add(toAddress);
                    message.Subject = subject;
                    message.IsBodyHtml = true;
                    message.Body = body;
                    smtpClient.Host = "relay-hosting.secureserver.net";   //-- Donot change.
                    smtpClient.Port = 25; //--- Donot change
                    smtpClient.EnableSsl = false;//--- Donot change
                    smtpClient.UseDefaultCredentials = true;
                    smtpClient.Credentials = new System.Net.NetworkCredential("support@rni-solutions.com", "jinitha123");

                    smtpClient.Send(message);

                }
                catch (Exception e)
                {

                    throw e;

                }
            }
        }
        //build a mail message
        private static MailMessage BuildMessageWith(string fromAddress, string toAddress, string subject, string body)
        {
            MailMessage message = new MailMessage
            {
                //Sender = new MailAddress(Settings.WebMasterEmail), // on Behave of When From differs
                From = new MailAddress(fromAddress),
                Subject = subject,
                Body = body,
                IsBodyHtml = true,
            };

            //   message.CC.Add("jinitha.s@rni-solutions.com");
            string[] tos = toAddress.Split(';');

            foreach (string to in tos)
            {

                message.To.Add(new MailAddress(to));
            }
            return message;
        }

        private static MailMessage BuildMessageWith(string fromAddress, string toAddress, string subject, string body, string attach)
        {
            MailMessage message = new MailMessage
            {
                //Sender = new MailAddress(Settings.WebMasterEmail), // on Behave of When From differs
                From = new MailAddress(fromAddress),
                Subject = subject,
                Body = body,
                IsBodyHtml = true,
            };

            //   message.CC.Add("jinitha.s@rni-solutions.com");
            string[] tos = toAddress.Split(';');

            foreach (string to in tos)
            {

                message.To.Add(new MailAddress(to));
            }
            message.Attachments.Add(new Attachment(attach));
            return message;
        }

        private static MailMessage BuildMessageWith(string fromAddress, string toAddress, string ccAddress, string bccAddress, string attach, string subject, string body)
        {

            MailMessage message = new MailMessage
            {
                //Sender = new MailAddress(Settings.WebMasterEmail), // on Behave of When From differs
                From = new MailAddress(fromAddress),
                Subject = subject,
                Body = body,
                IsBodyHtml = true,
            };


            string[] tos = toAddress.Split(';');
            string[] ccs = ccAddress.Split(';');
            string[] bccs = bccAddress.Split(';');
            string[] attachs = attach.Split(';');

            foreach (string to in tos)
            {
                message.To.Add(new MailAddress(to));
            }
            foreach (string cc in ccs)
            {
                message.CC.Add(new MailAddress(cc));
            }
            foreach (string bcc in bccs)
            {
                message.Bcc.Add(new MailAddress(bcc));
            }
            foreach (string attach1 in attachs)
            {
                message.Attachments.Add(new Attachment(attach1));
            }

            return message;
        }
        // read the text in template file and return it as a string
        private static string ReadFileFrom(string templateName)
        {
            string filePath = System.Web.HttpContext.Current.Server.MapPath(templateName);

            string body = File.ReadAllText(filePath);

            return body;
        }
        // get the template body, cache it and return the text
        private static string GetMailBodyOfTemplate(string templateName)
        {
            string cacheKey = string.Concat("mailTemplate:", templateName);
            string body;
            body = (string)System.Web.HttpContext.Current.Cache[cacheKey];
            if (string.IsNullOrEmpty(body))
            {
                //read template file text
                body = ReadFileFrom(templateName);

                if (!string.IsNullOrEmpty(body))
                {
                    System.Web.HttpContext.Current.Cache.Insert(cacheKey, body, null, DateTime.Now.AddHours(1), System.Web.Caching.Cache.NoSlidingExpiration);
                }
            }

            return body;
        }
        // replace the tokens in template body with corresponding values
        public string PrepareMailBodyWith(string templateName, params string[] pairs)
        {
            string body = GetMailBodyOfTemplate(templateName);

            for (var i = 0; i < pairs.Length; i += 2)
            {

                body = Regex.Replace(body, pairs[i], pairs[i + 1]);
                //body = body.Replace("<%={0}".FormatWith(pairs[i]), pairs[i + 1]);
            }
            return body;
        }
    }
}